import React from 'react';
import { usePayments } from '../../context/PaymentsContext';
import {
  Zap,
  ArrowRightLeft,
  BookOpenCheck,
  ShieldCheck,
  FileSpreadsheet,
  Globe2,
  TrendingUp,
  Building2,
  CheckCircle2,
  ArrowUpRight,
  Clock,
  Layers,
} from 'lucide-react';

export const OverviewView: React.FC<{ onNewPayoutClick: () => void }> = ({ onNewPayoutClick }) => {
  const {
    activeTenant,
    tenants,
    setSelectedTenantId,
    systemStats,
    setActiveTab,
    payouts,
  } = usePayments();

  const totalGtvAcrossTenants = tenants.reduce((acc, t) => acc + t.totalGtvUsd, 0);
  const totalSubMerchants = tenants.reduce((acc, t) => acc + t.subMerchantCount, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner / Pulse */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Infrastructure Pulse & Rail Operations
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            White-label embedded payment rails serving {tenants.length} vertical SaaS platforms and {totalSubMerchants.toLocaleString()} sub-merchants.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onNewPayoutClick}
            className="flex items-center gap-1.5 rounded bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 transition-colors"
          >
            <Zap className="h-3.5 w-3.5" />
            <span>Dispatch Real-Time Payout</span>
          </button>
        </div>
      </div>

      {/* High-Density Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400 font-medium">Cumulative Platform GTV</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-100">
            ${(totalGtvAcrossTenants).toLocaleString()}
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Active Tenants: <strong className="text-slate-200">{tenants.length}</strong></span>
            <span className="text-emerald-400 font-mono">+18.4% MoM</span>
          </div>
        </div>

        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400 font-medium">FedNow Direct Clearing Reserve</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-emerald-400">
            $14,850,920.00
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Federal Reserve Master Acct</span>
            <span className="text-emerald-400 font-mono">24/7/365</span>
          </div>
        </div>

        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400 font-medium">Sub-Merchant FBO Liability</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-100">
            $38,920,150.00
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Custodial client funds</span>
            <span className="text-indigo-400 font-mono">100% Backed</span>
          </div>
        </div>

        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400 font-medium">Clearing Settlement Exceptions</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-100">
            {systemStats.unreconciledExceptions === 0 ? (
              <span className="text-emerald-400">0 Items (Balanced)</span>
            ) : (
              <span className="text-rose-400">{systemStats.unreconciledExceptions} Flagged</span>
            )}
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>3-Way BAI2 Matching</span>
            <button
              onClick={() => setActiveTab('reconciliation')}
              className="text-indigo-400 hover:text-indigo-300 font-medium"
            >
              Reconcile →
            </button>
          </div>
        </div>
      </div>

      {/* Rail Performance and Live Settlement Throughput */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Rail Performance Comparison */}
        <div className="lg:col-span-7 rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-slate-200">
                Payment Rails Throughput & Latency Matrix
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Active rails automatically routed based on contractor preference and cut-off window.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {/* FedNow */}
            <div className="rounded border border-slate-800 bg-slate-900/60 p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span className="font-semibold text-slate-100">FedNow Service (Federal Reserve)</span>
                </div>
                <span className="font-mono text-emerald-400 font-bold">~1.4s settlement · $0.45</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div className="bg-emerald-500 h-1.5 rounded-full w-[84%]"></div>
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Direct RTGS participant</span>
                <span>84% of contractor disbursements</span>
              </div>
            </div>

            {/* RTP */}
            <div className="rounded border border-slate-800 bg-slate-900/60 p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-blue-400"></span>
                  <span className="font-semibold text-slate-100">The Clearing House (RTP)</span>
                </div>
                <span className="font-mono text-blue-400 font-bold">~2.8s settlement · $0.35</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div className="bg-blue-500 h-1.5 rounded-full w-[48%]"></div>
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>TCH Real-Time Network</span>
                <span>Chase, Citi, BofA, Wells Fargo</span>
              </div>
            </div>

            {/* Same-Day ACH */}
            <div className="rounded border border-slate-800 bg-slate-900/60 p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-indigo-400"></span>
                  <span className="font-semibold text-slate-100">NACHA Same-Day ACH</span>
                </div>
                <span className="font-mono text-indigo-300 font-bold">~4 hr batch window · $0.25</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div className="bg-indigo-500 h-1.5 rounded-full w-[32%]"></div>
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>ODFI 10:30, 14:45, 17:00 cut-offs</span>
                <span>High-ticket commercial invoices</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Vertical SaaS Platforms Comparison */}
        <div className="lg:col-span-5 rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200">
              Vertical SaaS Tenants
            </h2>
            <button
              onClick={() => setActiveTab('whitelabel')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
            >
              Configure Studio →
            </button>
          </div>

          <div className="divide-y divide-slate-800 rounded border border-slate-800 bg-slate-900/60 overflow-hidden text-xs">
            {tenants.map((tenant) => {
              const isSelected = tenant.id === activeTenant.id;
              return (
                <div
                  key={tenant.id}
                  onClick={() => setSelectedTenantId(tenant.id)}
                  className={`p-3 cursor-pointer transition-colors ${
                    isSelected ? 'bg-slate-800/60' : 'hover:bg-slate-800/30'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className="flex h-5 w-5 items-center justify-center rounded text-[10px] font-bold text-white"
                        style={{ backgroundColor: tenant.brandColor }}
                      >
                        {tenant.logoText}
                      </span>
                      <span className="font-medium text-slate-200">{tenant.name}</span>
                    </div>
                    <span className="font-mono text-emerald-400 font-semibold">
                      {(tenant.takeRateBps / 100).toFixed(2)}% take
                    </span>
                  </div>

                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>{tenant.subMerchantCount} sub-merchants</span>
                    <span>${(tenant.payoutVolume30d / 1000000).toFixed(1)}M/mo</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="rounded border border-indigo-900/30 bg-indigo-950/20 p-3 text-xs text-slate-300 flex items-center justify-between">
            <span>Active Tenant: <strong className="text-white">{activeTenant.name}</strong></span>
            <button
              onClick={() => setActiveTab('payouts')}
              className="text-indigo-400 hover:text-indigo-300 font-semibold text-xs"
            >
              View Payouts →
            </button>
          </div>
        </div>
      </div>

      {/* Recent Disbursed Stream */}
      <div className="rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">
              Recent Clearing Settlements
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Live payouts dispatched across vertical SaaS contractors with FedReference traces.
            </p>
          </div>

          <button
            onClick={() => setActiveTab('payouts')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
          >
            Full Payouts Ledger →
          </button>
        </div>

        <div className="overflow-x-auto rounded border border-slate-800 bg-slate-900/60">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/80">
                <th className="py-2.5 px-3">Transaction</th>
                <th className="py-2.5 px-3">Merchant Payee</th>
                <th className="py-2.5 px-3">Rail</th>
                <th className="py-2.5 px-3 text-right">Amount</th>
                <th className="py-2.5 px-3 text-right">Take Rate</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40">
              {payouts.slice(0, 5).map((p) => (
                <tr key={p.id} className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-3 text-slate-200 font-semibold">{p.id}</td>
                  <td className="py-2.5 px-3 font-sans text-slate-200">{p.merchantName}</td>
                  <td className="py-2.5 px-3 text-indigo-300 uppercase">{p.rail}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-100 tabular-nums">
                    ${p.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-semibold tabular-nums">
                    +${p.platformFee.toFixed(2)}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="text-emerald-400 flex items-center gap-1 font-sans text-[11px]">
                      <CheckCircle2 className="h-3 w-3" /> Settled
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
