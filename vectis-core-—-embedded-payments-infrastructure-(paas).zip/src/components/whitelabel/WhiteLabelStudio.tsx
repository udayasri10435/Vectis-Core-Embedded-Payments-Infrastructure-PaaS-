import React, { useState } from 'react';
import { usePayments } from '../../context/PaymentsContext';
import {
  Sliders,
  Sparkles,
  Building2,
  DollarSign,
  Palette,
  Globe,
  Shield,
  Smartphone,
  CheckCircle2,
  Zap,
  ArrowRight,
  Save,
} from 'lucide-react';

export const WhiteLabelStudio: React.FC = () => {
  const { activeTenant, updateTenant } = usePayments();

  const [brandColor, setBrandColor] = useState(activeTenant.brandColor);
  const [statementDescriptor, setStatementDescriptor] = useState(activeTenant.statementDescriptor);
  const [subdomain, setSubdomain] = useState(activeTenant.subdomain);
  const [takeRateBps, setTakeRateBps] = useState(activeTenant.takeRateBps);
  const [flatFeeCents, setFlatFeeCents] = useState(activeTenant.flatFeeCents);
  const [autoApproveThreshold, setAutoApproveThreshold] = useState(activeTenant.kybAutoApproveThreshold);
  const [previewMode, setPreviewMode] = useState<'onboarding' | 'wallet'>('wallet');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Projected Annual Platform Revenue
  const projectedAnnualRevenue = Math.round(
    (activeTenant.totalGtvUsd * (takeRateBps / 10000)) +
    (activeTenant.subMerchantCount * 48 * (flatFeeCents / 100))
  );

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateTenant(activeTenant.id, {
      brandColor,
      statementDescriptor,
      subdomain,
      takeRateBps,
      flatFeeCents,
      kybAutoApproveThreshold: autoApproveThreshold,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            White-Label Portal & Monetization Studio
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure seamless embedded banking and custom-branded payment experiences for your vertical SaaS platform.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="flex items-center gap-1.5 rounded bg-indigo-600 px-4 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 transition-colors"
        >
          <Save className="h-3.5 w-3.5" />
          <span>{savedSuccess ? 'Changes Saved!' : 'Deploy White-Label Config'}</span>
        </button>
      </div>

      {/* Split Configuration vs Live Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: White-Label Controls */}
        <div className="lg:col-span-5 space-y-5">
          <form onSubmit={handleSave} className="rounded border border-slate-800 bg-slate-900/50 p-5 space-y-5 text-xs">
            <div>
              <h2 className="text-sm font-semibold text-slate-200">
                Tenant Brand Customization
              </h2>
              <p className="text-slate-400 text-[11px] mt-0.5">
                Complete eradication of Vectis branding on end-customer screens.
              </p>
            </div>

            {/* Custom Brand Color */}
            <div className="space-y-1.5">
              <label className="block text-slate-300 font-medium">
                Primary Brand Accent
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={brandColor}
                  onChange={(e) => setBrandColor(e.target.value)}
                  className="h-8 w-12 rounded border border-slate-700 bg-slate-800 cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={brandColor}
                  onChange={(e) => setBrandColor(e.target.value)}
                  className="w-28 rounded border border-slate-700 bg-slate-900 px-2 py-1 text-slate-100 font-mono text-xs uppercase"
                />
                <div className="flex items-center gap-1.5">
                  {['#2563EB', '#E11D48', '#059669', '#7C3AED', '#F59E0B'].map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setBrandColor(c)}
                      className="h-5 w-5 rounded-full border border-slate-700"
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Subdomain */}
            <div className="space-y-1.5">
              <label className="block text-slate-300 font-medium">
                Custom White-Label Subdomain
              </label>
              <div className="flex items-center">
                <input
                  type="text"
                  value={subdomain}
                  onChange={(e) => setSubdomain(e.target.value)}
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-slate-100 font-mono text-xs"
                />
              </div>
            </div>

            {/* Statement Descriptor */}
            <div className="space-y-1.5">
              <label className="block text-slate-300 font-medium">
                Bank Statement Payout Descriptor
              </label>
              <input
                type="text"
                value={statementDescriptor}
                onChange={(e) => setStatementDescriptor(e.target.value.toUpperCase())}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-slate-100 font-mono text-xs uppercase"
                maxLength={22}
              />
              <span className="text-[10px] text-slate-400">
                Appears on sub-merchants' external bank statements. Max 22 characters.
              </span>
            </div>

            {/* Take-Rate Monetization Calculator */}
            <div className="pt-3 border-t border-slate-800 space-y-3">
              <div>
                <h3 className="text-xs font-semibold text-slate-200">
                  Platform Software Take-Rate Monetization
                </h3>
                <p className="text-[11px] text-slate-400">
                  Your platform captures revenue on every payout executed.
                </p>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Take Rate (Basis Points):</span>
                  <span className="font-mono font-semibold text-emerald-400">
                    {takeRateBps} bps ({(takeRateBps / 100).toFixed(2)}%)
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="150"
                  step="5"
                  value={takeRateBps}
                  onChange={(e) => setTakeRateBps(parseInt(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Fixed Flat Fee per Payout:</span>
                  <span className="font-mono font-semibold text-emerald-400">
                    ${(flatFeeCents / 100).toFixed(2)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="200"
                  step="5"
                  value={flatFeeCents}
                  onChange={(e) => setFlatFeeCents(parseInt(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>

              <div className="rounded border border-emerald-500/20 bg-emerald-950/20 p-3 font-mono">
                <span className="text-[10px] text-emerald-400/80 block uppercase">
                  Projected SaaS Annual Take-Rate Revenue
                </span>
                <span className="text-lg font-bold text-emerald-400 tabular-nums">
                  ${projectedAnnualRevenue.toLocaleString()} / yr
                </span>
                <span className="text-[10px] text-slate-400 font-sans block mt-0.5">
                  Calculated on ${(activeTenant.totalGtvUsd).toLocaleString()} GTV and {activeTenant.subMerchantCount} active contractors.
                </span>
              </div>
            </div>

            {/* Risk Auto-Approve Threshold */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>KYB Auto-Approve Score Threshold:</span>
                <span className="font-mono font-semibold text-indigo-400">
                  Score &lt; {autoApproveThreshold}
                </span>
              </div>
              <input
                type="range"
                min="5"
                max="50"
                value={autoApproveThreshold}
                onChange={(e) => setAutoApproveThreshold(parseInt(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
              <span className="text-[10px] text-slate-400 block">
                Applications with algorithmic risk scores below {autoApproveThreshold} bypass manual queue and enable instant payouts immediately.
              </span>
            </div>
          </form>
        </div>

        {/* Right Column: Live Embedded Component Preview */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smartphone className="h-4 w-4 text-indigo-400" />
              <span className="text-xs font-semibold text-slate-200">
                Live Sub-Merchant Interactive Preview
              </span>
            </div>

            <div className="flex items-center gap-1 p-1 bg-slate-900/80 rounded border border-slate-800 text-xs">
              <button
                onClick={() => setPreviewMode('wallet')}
                className={`px-3 py-1 rounded transition-colors ${
                  previewMode === 'wallet'
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Embedded Wallet Component
              </button>
              <button
                onClick={() => setPreviewMode('onboarding')}
                className={`px-3 py-1 rounded transition-colors ${
                  previewMode === 'onboarding'
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Hosted KYC/KYB Onboarding
              </button>
            </div>
          </div>

          {/* Browser / Component Mock Frame */}
          <div className="rounded-xl border border-slate-800 bg-[#0d131f] shadow-2xl overflow-hidden">
            {/* Browser Address Bar */}
            <div className="flex items-center gap-2 bg-slate-950 px-4 py-2.5 border-b border-slate-800 text-xs font-mono text-slate-400">
              <div className="flex gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-slate-800"></span>
                <span className="h-2.5 w-2.5 rounded-full bg-slate-800"></span>
                <span className="h-2.5 w-2.5 rounded-full bg-slate-800"></span>
              </div>
              <div className="flex-1 text-center bg-slate-900 rounded py-1 px-3 text-[11px] text-slate-300 truncate">
                https://{subdomain}/dashboard
              </div>
            </div>

            {/* Embedded Component Canvas */}
            <div className="p-6">
              {previewMode === 'wallet' ? (
                /* Embedded Wallet Component */
                <div className="max-w-md mx-auto rounded-lg border border-slate-800 bg-slate-900/90 p-5 space-y-4 shadow-xl">
                  {/* Brand Header */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <span
                        className="flex h-7 w-7 items-center justify-center rounded text-white font-bold text-xs"
                        style={{ backgroundColor: brandColor }}
                      >
                        {activeTenant.logoText}
                      </span>
                      <span className="font-semibold text-slate-100 text-xs">
                        {activeTenant.name} Payouts
                      </span>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                      FedNow 24/7 Enabled
                    </span>
                  </div>

                  {/* Balance Display */}
                  <div className="rounded p-4 space-y-1 bg-slate-950/60 border border-slate-800/80">
                    <span className="text-[11px] text-slate-400">Available Balance</span>
                    <div className="text-2xl font-bold font-mono text-white tabular-nums">
                      $18,450.00
                    </div>
                    <div className="text-[11px] text-slate-400 pt-1 flex items-center justify-between">
                      <span>Routing to Chase Business ••••9142</span>
                      <span className="text-emerald-400 font-mono">Instant Payout</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2">
                    <button
                      className="w-full py-2.5 rounded font-semibold text-xs text-white shadow transition-transform active:scale-98 flex items-center justify-center gap-1.5"
                      style={{ backgroundColor: brandColor }}
                    >
                      <Zap className="h-3.5 w-3.5" />
                      <span>Instant Cash Out (FedNow)</span>
                    </button>
                    <button className="w-full py-2 rounded font-medium text-xs text-slate-300 hover:bg-slate-800/60 transition-colors border border-slate-800">
                      Standard ACH (No Fee)
                    </button>
                  </div>

                  <div className="text-[10px] text-slate-400 text-center">
                    Statement descriptor: <span className="font-mono text-slate-300">{statementDescriptor}</span>
                  </div>
                </div>
              ) : (
                /* Hosted KYC/KYB Onboarding Experience */
                <div className="max-w-md mx-auto rounded-lg border border-slate-800 bg-slate-900/90 p-5 space-y-4 shadow-xl text-xs">
                  <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                    <span
                      className="flex h-7 w-7 items-center justify-center rounded text-white font-bold text-xs"
                      style={{ backgroundColor: brandColor }}
                    >
                      {activeTenant.logoText}
                    </span>
                    <div>
                      <h4 className="font-semibold text-slate-100 text-xs">
                        {activeTenant.name} Merchant Onboarding
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        Enable instant payouts for your business
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">
                        Legal Business Name
                      </label>
                      <input
                        type="text"
                        readOnly
                        value="Lone Star Mechanical & AC LLC"
                        className="w-full rounded border border-slate-800 bg-slate-950 px-3 py-1.5 text-slate-200"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">
                          Tax ID (EIN)
                        </label>
                        <input
                          type="text"
                          readOnly
                          value="••-•••4912"
                          className="w-full rounded border border-slate-800 bg-slate-950 px-3 py-1.5 text-slate-200 font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-medium mb-1">
                          Structure
                        </label>
                        <input
                          type="text"
                          readOnly
                          value="LLC"
                          className="w-full rounded border border-slate-800 bg-slate-950 px-3 py-1.5 text-slate-200"
                        />
                      </div>
                    </div>

                    <div className="rounded border border-emerald-500/20 bg-emerald-950/20 p-2.5 flex items-center gap-2 text-[11px] text-emerald-300">
                      <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                      <span>Federal EIN & Beneficial Owner verified via FinCEN FastTrack</span>
                    </div>

                    <button
                      className="w-full py-2.5 rounded font-semibold text-xs text-white shadow"
                      style={{ backgroundColor: brandColor }}
                    >
                      Complete Registration & Link Bank
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
