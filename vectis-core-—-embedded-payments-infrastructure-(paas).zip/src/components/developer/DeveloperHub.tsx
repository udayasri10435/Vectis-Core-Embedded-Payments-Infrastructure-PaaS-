import React, { useState } from 'react';
import { usePayments } from '../../context/PaymentsContext';
import {
  Terminal,
  Code2,
  Copy,
  Check,
  Play,
  Webhook,
  ShieldCheck,
  Send,
  Radio,
  FileCode,
  CheckCircle2,
} from 'lucide-react';

export const DeveloperHub: React.FC = () => {
  const { webhooks, dispatchTestWebhook, activeTenant } = usePayments();

  const [activeEndpoint, setActiveEndpoint] = useState<'payouts' | 'ledger' | 'kyb' | 'recon'>('payouts');
  const [selectedLanguage, setSelectedLanguage] = useState<'curl' | 'typescript' | 'python'>('typescript');
  const [copiedCode, setCopiedCode] = useState(false);
  const [isExecutingApi, setIsExecutingApi] = useState(false);
  const [apiResponse, setApiResponse] = useState<string | null>(null);

  const [selectedWebhook, setSelectedWebhook] = useState(webhooks[0]);
  const [simWebhookEvent, setSimWebhookEvent] = useState('payout.settled');

  const getCodeSnippet = () => {
    switch (activeEndpoint) {
      case 'payouts':
        if (selectedLanguage === 'curl') {
          return `curl -X POST https://api.vectiscore.com/v1/payouts \\
  -H "Authorization: Bearer vct_live_${activeTenant.slug}_secret" \\
  -H "Idempotency-Key: idemp_${Date.now()}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "merchant_id": "subm_78912",
    "amount": 2500.00,
    "currency": "usd",
    "rail": "fednow",
    "purpose": "Emergency contractor progress billing"
  }'`;
        }
        if (selectedLanguage === 'typescript') {
          return `import { VectisClient } from '@vectis/node-sdk';

const vectis = new VectisClient({
  apiKey: process.env.VECTIS_SECRET_KEY,
  tenant: '${activeTenant.slug}',
});

const payout = await vectis.payouts.create({
  merchantId: 'subm_78912',
  amount: 2500.00,
  currency: 'USD',
  rail: 'fednow', // Instant settlement <2s
  purpose: 'Emergency contractor progress billing',
}, {
  idempotencyKey: 'idemp_${Date.now()}',
});

console.log('Settled with Trace:', payout.traceNumber);`;
        }
        return `import vectis

client = vectis.Client(api_key="vct_live_${activeTenant.slug}_secret")

payout = client.payouts.create(
    merchant_id="subm_78912",
    amount=2500.00,
    currency="USD",
    rail="fednow",
    purpose="Emergency contractor progress billing"
)
print(f"Settled via FedNow: {payout.trace_number}")`;

      case 'ledger':
        if (selectedLanguage === 'typescript') {
          return `const entry = await vectis.ledger.entries.create({
  description: 'Card Clearing Split & Platform Take',
  lines: [
    { accountCode: '1020', direction: 'debit', amount: 5000.00, currency: 'USD' },
    { accountCode: '2010', direction: 'credit', amount: 4850.00, currency: 'USD' },
    { accountCode: '4010', direction: 'credit', amount: 150.00, currency: 'USD' },
  ],
});
// Invariant check: sum(debit) === sum(credit)`;
        }
        return `curl -X POST https://api.vectiscore.com/v1/ledger/entries \\
  -H "Authorization: Bearer vct_live_secret" \\
  -d '{"description": "Settlement", "lines": [...]}'`;

      case 'kyb':
        return `const kybCase = await vectis.entities.submitKyb({
  legalBusinessName: 'Apex Mechanical LLC',
  ein: '84-2938174',
  businessType: 'LLC',
  beneficialOwners: [{
    fullName: 'Marcus Vance',
    ssnLast4: '4192',
    ownershipPct: 60,
  }],
});`;

      case 'recon':
        return `const recon = await vectis.reconciliation.submitClearingFile({
  format: 'BAI2',
  statementDate: '2026-09-28',
  rail: 'fednow',
});`;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getCodeSnippet());
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 1500);
  };

  const handleExecuteApi = () => {
    setIsExecutingApi(true);
    setApiResponse(null);
    setTimeout(() => {
      const mockResult = {
        id: `pay_fn_${Math.floor(100000 + Math.random() * 900000)}`,
        object: 'payout',
        rail: 'fednow',
        amount: 2500.0,
        currency: 'USD',
        status: 'settled',
        trace_number: `FEDNOW-20260928-TX${Math.floor(100000000 + Math.random() * 900000000)}`,
        iso20022_message_id: 'pacs.008.001.08/VECTIS2026',
        clearing_network: 'Federal Reserve FedNow Service',
        settled_at: new Date().toISOString(),
        ledger_entry: {
          id: `je_${Date.now()}`,
          debit_account: '2010 (Sub-Merchant FBO Custodial Liability)',
          credit_account: '1010 (FedNow Master Settlement Asset)',
          balanced: true,
        },
      };
      setApiResponse(JSON.stringify(mockResult, null, 2));
      setIsExecutingApi(false);
    }, 500);
  };

  const handleDispatchTest = () => {
    dispatchTestWebhook(simWebhookEvent, {
      test: true,
      timestamp: new Date().toISOString(),
      event: simWebhookEvent,
      tenant: activeTenant.slug,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Developer Hub & API Console
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Integrate white-label rails directly into your vertical SaaS codebase using modern REST endpoints and typed SDKs.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-slate-400">
          <span>SDK Version:</span>
          <span className="text-emerald-400 font-semibold">@vectis/node-sdk v3.4.1</span>
        </div>
      </div>

      {/* API Request Runner */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Endpoint selector & Code Editor */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded border border-slate-800 bg-slate-900/60 p-4 space-y-4">
            {/* Endpoints navigation */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-1 text-xs">
                {[
                  { id: 'payouts', label: 'POST /v1/payouts' },
                  { id: 'ledger', label: 'POST /v1/ledger/entries' },
                  { id: 'kyb', label: 'POST /v1/entities/kyb' },
                  { id: 'recon', label: 'POST /v1/reconciliation' },
                ].map((ep) => (
                  <button
                    key={ep.id}
                    onClick={() => {
                      setActiveEndpoint(ep.id as any);
                      setApiResponse(null);
                    }}
                    className={`px-2.5 py-1 rounded font-mono text-xs transition-colors ${
                      activeEndpoint === ep.id
                        ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {ep.label}
                  </button>
                ))}
              </div>

              {/* Language Switcher */}
              <div className="flex items-center gap-1 text-xs font-mono">
                {(['typescript', 'curl', 'python'] as const).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setSelectedLanguage(lang)}
                    className={`px-2 py-0.5 rounded capitalize ${
                      selectedLanguage === lang
                        ? 'bg-slate-800 text-white font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {lang}
                  </button>
                ))}
              </div>
            </div>

            {/* Code Block with Copy Action */}
            <div className="relative rounded border border-slate-800 bg-[#090d15] p-4 font-mono text-xs text-slate-200 overflow-x-auto">
              <button
                onClick={handleCopy}
                className="absolute right-3 top-3 rounded bg-slate-800/80 p-1.5 text-slate-400 hover:text-slate-200 transition-colors"
                title="Copy code"
              >
                {copiedCode ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              </button>
              <pre className="pr-10 leading-relaxed">{getCodeSnippet()}</pre>
            </div>

            {/* Run Button */}
            <div className="flex justify-between items-center pt-1">
              <span className="text-[11px] text-slate-400 font-mono">
                Environment: <strong className="text-slate-200">https://api.vectiscore.com</strong>
              </span>
              <button
                onClick={handleExecuteApi}
                disabled={isExecutingApi}
                className="flex items-center gap-1.5 rounded bg-indigo-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors shadow"
              >
                <Play className={`h-3.5 w-3.5 ${isExecutingApi ? 'animate-spin' : ''}`} />
                <span>{isExecutingApi ? 'Executing Request...' : 'Send Test Request'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right: Real HTTP Response Payload */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded border border-slate-800 bg-slate-900/60 p-4 space-y-3 min-h-[360px] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-200">
                  HTTP Response
                </span>
                {apiResponse && (
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-1.5 py-0.5 rounded">
                    200 OK (38ms)
                  </span>
                )}
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                application/json
              </span>
            </div>

            <div className="flex-1 rounded border border-slate-800 bg-[#090d15] p-3 font-mono text-xs text-slate-300 overflow-x-auto">
              {apiResponse ? (
                <pre className="text-emerald-400/90 leading-relaxed">{apiResponse}</pre>
              ) : (
                <div className="h-full flex items-center justify-center text-slate-400 text-xs text-center p-6">
                  Click "Send Test Request" to execute against the active sandbox ledger and return ISO 20022 clearing receipt.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Webhooks Dispatcher & Inspector */}
      <div className="rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Webhook className="h-4 w-4 text-indigo-400" />
              <h2 className="text-sm font-semibold text-slate-200">
                Webhook Event Stream & Signature Verifier
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Verified with HMAC-SHA256 signature headers (`Vectis-Signature`) to guarantee origin.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={simWebhookEvent}
              onChange={(e) => setSimWebhookEvent(e.target.value)}
              className="rounded border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs text-slate-200"
            >
              <option value="payout.settled">payout.settled</option>
              <option value="kyb.approved">kyb.approved</option>
              <option value="ledger.entry_created">ledger.entry_created</option>
            </select>
            <button
              onClick={handleDispatchTest}
              className="rounded bg-slate-800 border border-slate-700 px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-slate-700 transition-colors flex items-center gap-1.5"
            >
              <Send className="h-3 w-3 text-indigo-400" />
              <span>Simulate Webhook Dispatch</span>
            </button>
          </div>
        </div>

        {/* Webhooks Table */}
        <div className="overflow-x-auto rounded border border-slate-800 bg-slate-900/60">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/80">
                <th className="py-2.5 px-3">Event ID</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">HMAC-SHA256 Signature</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40">
              {webhooks.slice(0, 5).map((wh) => (
                <tr key={wh.id} className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-3 text-slate-200 font-semibold">{wh.id}</td>
                  <td className="py-2.5 px-3 text-indigo-400 font-semibold">{wh.event}</td>
                  <td className="py-2.5 px-3 text-emerald-400">
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" /> {wh.httpStatus} Delivered
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                    {new Date(wh.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 truncate max-w-[200px] text-[10px]">
                    {wh.signature}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
