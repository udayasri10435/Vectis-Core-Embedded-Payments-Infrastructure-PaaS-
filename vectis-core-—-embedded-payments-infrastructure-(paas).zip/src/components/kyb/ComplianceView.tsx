import React, { useState } from 'react';
import { usePayments } from '../../context/PaymentsContext';
import { KybCase, KybCaseDocument } from '../../types';
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileText,
  Clock,
  ExternalLink,
  ChevronRight,
  UserCheck,
  Building,
  Plus,
  Send,
  Eye,
  X,
} from 'lucide-react';

export const ComplianceView: React.FC = () => {
  const {
    kybCases,
    tenantKybCases,
    updateKybCaseStatus,
    addMerchant,
    activeTenant,
  } = usePayments();

  const [selectedCaseId, setSelectedCaseId] = useState<string>(
    kybCases[0]?.id || ''
  );
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [newNoteText, setNewNoteText] = useState('');
  const [previewDoc, setPreviewDoc] = useState<KybCaseDocument | null>(null);
  const [showSimulateModal, setShowSimulateModal] = useState(false);

  // New simulated onboarding form
  const [simName, setSimName] = useState('Ironclad Roofing & Solar Solutions LLC');
  const [simEin, setSimEin] = useState('88-4910283');
  const [simOwner, setSimOwner] = useState('Derrick Brooks');

  const filteredCases = kybCases.filter((c) => {
    if (filterStatus === 'all') return true;
    return c.status === filterStatus;
  });

  const selectedCase =
    kybCases.find((c) => c.id === selectedCaseId) || kybCases[0];

  const handleDecision = (status: KybCase['status']) => {
    if (!selectedCase) return;
    const note =
      status === 'approved'
        ? 'Manual review completed: All FinCEN CDD & IRS TIN requirements satisfied.'
        : status === 'action_required'
        ? 'Requesting updated beneficial ownership disclosure for offshore parent.'
        : 'Merchant business model flagged for elevated chargeback/prohibited risk.';
    updateKybCaseStatus(selectedCase.id, status, note);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim() || !selectedCase) return;
    updateKybCaseStatus(selectedCase.id, selectedCase.status, newNoteText);
    setNewNoteText('');
  };

  const handleSimulateOnboard = (e: React.FormEvent) => {
    e.preventDefault();
    const newM = addMerchant({
      legalBusinessName: simName,
      dba: simName.replace(' LLC', ''),
      ein: simEin,
      beneficialOwner: {
        fullName: simOwner,
        title: 'Founder / General Partner',
        ownershipPct: 100,
        ssnLast4: '3819',
        dob: '1987-07-22',
        email: 'derrick@ironcladroofing.pro',
      },
    });
    setShowSimulateModal(false);
    setSelectedCaseId(`kyb_case_${newM.id.slice(-4)}`);
  };

  const renderCheckIcon = (status: 'passed' | 'review' | 'failed') => {
    if (status === 'passed') {
      return <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />;
    }
    if (status === 'review') {
      return <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0" />;
    }
    return <XCircle className="h-4 w-4 text-rose-400 shrink-0" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            KYB & KYC Compliance Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            FinCEN Customer Due Diligence (CDD), IRS TIN Matching, OFAC SDN Watchlist, and UBO verification.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowSimulateModal(true)}
            className="flex items-center gap-1.5 rounded bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 transition-colors"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Simulate Contractor Onboarding</span>
          </button>
        </div>
      </div>

      {/* Main Split Layout: Queue on Left, Case Dossier on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Cases Queue */}
        <div className="lg:col-span-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200">
              Verification Queue ({filteredCases.length})
            </span>
            <div className="flex items-center gap-1 text-[11px]">
              {['all', 'pending_review', 'approved'].map((st) => (
                <button
                  key={st}
                  onClick={() => setFilterStatus(st)}
                  className={`px-2 py-0.5 rounded capitalize ${
                    filterStatus === st
                      ? 'bg-slate-800 text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {st.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            {filteredCases.map((c) => {
              const isSelected = selectedCase?.id === c.id;
              return (
                <div
                  key={c.id}
                  onClick={() => setSelectedCaseId(c.id)}
                  className={`rounded border p-3 cursor-pointer transition-all ${
                    isSelected
                      ? 'border-indigo-500 bg-slate-900/90 shadow-sm'
                      : 'border-slate-800 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-200 truncate max-w-[190px]">
                      {c.legalBusinessName}
                    </span>
                    <span
                      className={`text-[10px] font-mono capitalize ${
                        c.status === 'approved'
                          ? 'text-emerald-400'
                          : c.status === 'pending_review'
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {c.status.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-400 mt-1 truncate">
                    {c.beneficialOwnerName}
                  </div>

                  <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                    <span>Risk Score: {c.riskScore}/100</span>
                    <span>{new Date(c.submittedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Case Dossier */}
        <div className="lg:col-span-8 space-y-4">
          {selectedCase ? (
            <div className="rounded border border-slate-800 bg-slate-900/40 p-5 space-y-5">
              {/* Dossier Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-slate-100">
                      {selectedCase.legalBusinessName}
                    </h2>
                    <span
                      className={`text-xs font-mono font-semibold ${
                        selectedCase.status === 'approved'
                          ? 'text-emerald-400'
                          : selectedCase.status === 'pending_review'
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      · {selectedCase.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    {selectedCase.businessAddress} · DBA: {selectedCase.dba}
                  </div>
                  <div className="text-xs text-indigo-300 font-mono mt-1">
                    Beneficial Owner: {selectedCase.beneficialOwnerName}
                  </div>
                </div>

                {/* Decision Action Buttons */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDecision('approved')}
                    className="flex items-center gap-1.5 rounded bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors shadow-sm"
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>Approve KYB</span>
                  </button>
                  <button
                    onClick={() => handleDecision('action_required')}
                    className="flex items-center gap-1.5 rounded bg-amber-600/20 border border-amber-500/30 px-3 py-1.5 text-xs font-semibold text-amber-300 hover:bg-amber-600/30 transition-colors"
                  >
                    <AlertTriangle className="h-3.5 w-3.5" />
                    <span>Request Docs</span>
                  </button>
                  <button
                    onClick={() => handleDecision('rejected')}
                    className="rounded bg-rose-600/20 border border-rose-500/30 px-3 py-1.5 text-xs font-semibold text-rose-300 hover:bg-rose-600/30 transition-colors"
                  >
                    Reject
                  </button>
                </div>
              </div>

              {/* 6-Point Automated Compliance Screen */}
              <div>
                <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2.5">
                  Automated Regulatory & Risk Screen
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="rounded border border-slate-800 bg-slate-900/60 p-3 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200">
                        1. Secretary of State Registry
                      </span>
                      {renderCheckIcon(selectedCase.checks.sosRegistration.status)}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {selectedCase.checks.sosRegistration.detail}
                    </p>
                  </div>

                  <div className="rounded border border-slate-800 bg-slate-900/60 p-3 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200">
                        2. IRS TIN / EIN Match
                      </span>
                      {renderCheckIcon(selectedCase.checks.tinMatching.status)}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {selectedCase.checks.tinMatching.detail}
                    </p>
                  </div>

                  <div className="rounded border border-slate-800 bg-slate-900/60 p-3 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200">
                        3. FinCEN Beneficial Ownership (25%+)
                      </span>
                      {renderCheckIcon(selectedCase.checks.fincenUboCheck.status)}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {selectedCase.checks.fincenUboCheck.detail}
                    </p>
                  </div>

                  <div className="rounded border border-slate-800 bg-slate-900/60 p-3 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200">
                        4. OFAC & Global Sanctions (SDN)
                      </span>
                      {renderCheckIcon(selectedCase.checks.ofacSanctions.status)}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {selectedCase.checks.ofacSanctions.detail}
                    </p>
                  </div>

                  <div className="rounded border border-slate-800 bg-slate-900/60 p-3 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200">
                        5. Adverse Media & Politically Exposed
                      </span>
                      {renderCheckIcon(selectedCase.checks.adverseMedia.status)}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {selectedCase.checks.adverseMedia.detail}
                    </p>
                  </div>

                  <div className="rounded border border-slate-800 bg-slate-900/60 p-3 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200">
                        6. Bank Account Title Match
                      </span>
                      {renderCheckIcon(selectedCase.checks.bankAccountAuth.status)}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {selectedCase.checks.bankAccountAuth.detail}
                    </p>
                  </div>
                </div>
              </div>

              {/* Uploaded Documents Grid */}
              <div>
                <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2.5">
                  Verified Documentation Vault ({selectedCase.documents.length})
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {selectedCase.documents.map((doc) => (
                    <div
                      key={doc.id}
                      className="flex items-center justify-between rounded border border-slate-800 bg-slate-900/50 p-2.5 hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-center gap-2 truncate">
                        <FileText className="h-4 w-4 text-indigo-400 shrink-0" />
                        <div className="truncate">
                          <div className="font-medium text-slate-200 truncate">{doc.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {doc.fileSize} · {doc.status}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => setPreviewDoc(doc)}
                        className="text-indigo-400 hover:text-indigo-300 p-1 font-medium flex items-center gap-1 text-[11px]"
                      >
                        <Eye className="h-3.5 w-3.5" />
                        View
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reviewer Audit Trail & Notes */}
              <div>
                <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2.5">
                  Compliance Audit Log & Notes
                </h3>
                <div className="rounded border border-slate-800 bg-slate-900/30 p-3 space-y-2">
                  {selectedCase.reviewerNotes.map((note, i) => (
                    <div key={i} className="text-xs text-slate-300 flex items-start gap-2">
                      <span className="text-indigo-400 font-mono text-[10px] mt-0.5">▸</span>
                      <span>{note}</span>
                    </div>
                  ))}

                  <form onSubmit={handleAddNote} className="mt-3 pt-3 border-t border-slate-800 flex gap-2">
                    <input
                      type="text"
                      value={newNoteText}
                      onChange={(e) => setNewNoteText(e.target.value)}
                      placeholder="Add compliance officer note or regulatory memorandum..."
                      className="flex-1 rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-slate-100 outline-none focus:border-indigo-500"
                    />
                    <button
                      type="submit"
                      disabled={!newNoteText.trim()}
                      className="rounded bg-slate-800 border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 disabled:opacity-50"
                    >
                      <Send className="h-3.5 w-3.5" />
                    </button>
                  </form>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded border border-slate-800 bg-slate-900/40 p-8 text-center text-xs text-slate-400">
              Select a verification case from the queue to view audit dossier.
            </div>
          )}
        </div>
      </div>

      {/* Document Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-lg border border-slate-700 bg-[#0e1626] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-indigo-400" />
                <h3 className="text-sm font-semibold text-slate-100">
                  {previewDoc.name}
                </h3>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="rounded border border-slate-800 bg-slate-900 p-6 text-center space-y-3">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-slate-800 text-indigo-400">
                <CheckCircle2 className="h-6 w-6 text-emerald-400" />
              </div>
              <div className="font-mono text-xs text-slate-200 font-semibold">
                Cryptographic Signature Verified
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed max-w-sm mx-auto">
                Official document verified against Secretary of State and IRS optical character recognition (OCR) models. Zero tampering detected.
              </p>
              <div className="text-[10px] font-mono text-slate-400 pt-2 border-t border-slate-800">
                SHA-256: 8f49a01c382b...4491
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setPreviewDoc(null)}
                className="rounded bg-slate-800 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Simulate Contractor Onboarding Modal */}
      {showSimulateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-lg border border-slate-700 bg-[#0e1626] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-semibold text-slate-100">
                Simulate Sub-Merchant Onboarding
              </h3>
              <button
                onClick={() => setShowSimulateModal(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSimulateOnboard} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Legal Business Name
                </label>
                <input
                  type="text"
                  value={simName}
                  onChange={(e) => setSimName(e.target.value)}
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Federal EIN
                </label>
                <input
                  type="text"
                  value={simEin}
                  onChange={(e) => setSimEin(e.target.value)}
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-slate-100 font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Primary Beneficial Owner (UBO)
                </label>
                <input
                  type="text"
                  value={simOwner}
                  onChange={(e) => setSimOwner(e.target.value)}
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-slate-100"
                  required
                />
              </div>

              <div className="text-[11px] text-slate-400">
                Will submit through {activeTenant.name}'s white-label embedded onboarding flow and trigger compliance screening.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowSimulateModal(false)}
                  className="rounded border border-slate-700 px-3 py-1.5 text-slate-300 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-indigo-600 px-4 py-1.5 font-semibold text-white hover:bg-indigo-500"
                >
                  Submit Application
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
