import React from 'react';
import { usePayments, NavigationTab } from '../../context/PaymentsContext';
import {
  Layers,
  ArrowRightLeft,
  BookOpenCheck,
  ShieldCheck,
  FileSpreadsheet,
  Globe2,
  Sliders,
  Terminal,
  Zap,
} from 'lucide-react';

export const TopHeader: React.FC<{ onNewPayoutClick: () => void }> = ({ onNewPayoutClick }) => {
  const {
    environment,
    setEnvironment,
    activeTab,
    setActiveTab,
    tenants,
    selectedTenantId,
    setSelectedTenantId,
    activeTenant,
    systemStats,
  } = usePayments();

  const navItems: { id: NavigationTab; label: string; icon: React.ElementType }[] = [
    { id: 'overview', label: 'Overview', icon: Layers },
    { id: 'payouts', label: 'Payout Rails', icon: ArrowRightLeft },
    { id: 'ledger', label: 'Ledger', icon: BookOpenCheck },
    { id: 'compliance', label: 'KYB & KYC', icon: ShieldCheck },
    { id: 'reconciliation', label: 'Reconciliation', icon: FileSpreadsheet },
    { id: 'treasury', label: 'Treasury', icon: Globe2 },
    { id: 'whitelabel', label: 'White-Label', icon: Sliders },
    { id: 'developer', label: 'API & Webhooks', icon: Terminal },
  ];

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-800 bg-[#0c121e]/95 px-6 backdrop-blur-md">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-6">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('overview');
          }}
          className="text-lg font-bold tracking-tight text-white flex items-center gap-2.5 group"
        >
          <span className="flex h-7 w-7 items-center justify-center rounded bg-gradient-to-br from-indigo-500 to-blue-600 font-mono text-xs font-bold text-white shadow-sm">
            V
          </span>
          <span className="font-semibold tracking-tight text-slate-100">
            Vectis <span className="text-slate-400 font-normal">Core</span>
          </span>
        </a>

        {/* Tenant Switcher dropdown */}
        <div className="hidden lg:flex items-center gap-2 border-l border-slate-800 pl-6">
          <span className="text-xs text-slate-400">Platform Tenant:</span>
          <select
            value={selectedTenantId}
            onChange={(e) => setSelectedTenantId(e.target.value)}
            className="rounded border border-slate-700 bg-slate-900/90 px-2.5 py-1 text-xs font-medium text-slate-200 outline-none hover:border-slate-600 focus:border-indigo-500"
          >
            {tenants.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.industry})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden xl:flex items-center gap-1">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                isActive
                  ? 'bg-slate-800 text-white shadow-inner font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <item.icon className="h-3.5 w-3.5" />
              <span>{item.label}</span>
              {item.id === 'compliance' && systemStats.pendingKybReviews > 0 && (
                <span className="ml-1 text-[10px] text-amber-400 font-mono">
                  ({systemStats.pendingKybReviews})
                </span>
              )}
              {item.id === 'reconciliation' && systemStats.unreconciledExceptions > 0 && (
                <span className="ml-1 text-[10px] text-rose-400 font-mono">
                  ({systemStats.unreconciledExceptions})
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: 1-2 Primary Actions */}
      <div className="flex items-center gap-3">
        {/* Environment toggle */}
        <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 text-xs">
          <button
            onClick={() => setEnvironment('live')}
            className={`px-2.5 py-1 rounded transition-colors text-[11px] font-medium ${
              environment === 'live'
                ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Live Rails
          </button>
          <button
            onClick={() => setEnvironment('sandbox')}
            className={`px-2.5 py-1 rounded transition-colors text-[11px] font-medium ${
              environment === 'sandbox'
                ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Sandbox
          </button>
        </div>

        {/* Primary CTA */}
        <button
          onClick={onNewPayoutClick}
          className="flex items-center gap-1.5 rounded bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 active:scale-95 transition-all whitespace-nowrap"
        >
          <Zap className="h-3.5 w-3.5" />
          <span>Dispatch Payout</span>
        </button>
      </div>
    </header>
  );
};
