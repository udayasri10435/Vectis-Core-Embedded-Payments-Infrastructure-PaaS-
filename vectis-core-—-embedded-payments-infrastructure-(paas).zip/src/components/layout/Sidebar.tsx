import React from 'react';
import { usePayments, NavigationTab } from '../../context/PaymentsContext';
import {
  Layers,
  ArrowRightLeft,
  BookOpenCheck,
  ShieldCheck,
  FileSpreadsheet,
  Globe2,
  Sliders,
  Terminal,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Building2,
  ExternalLink,
} from 'lucide-react';

export const Sidebar: React.FC<{ onNewPayoutClick: () => void }> = ({ onNewPayoutClick }) => {
  const {
    activeTab,
    setActiveTab,
    activeTenant,
    systemStats,
    environment,
  } = usePayments();

  const coreNav: { id: NavigationTab; label: string; icon: React.ElementType; badge?: number | string; badgeColor?: string }[] = [
    { id: 'overview', label: 'Overview & Pulse', icon: Layers },
    { id: 'payouts', label: 'Payout Rails (FedNow/RTP)', icon: ArrowRightLeft },
    { id: 'ledger', label: 'Double-Entry Ledger', icon: BookOpenCheck },
    {
      id: 'compliance',
      label: 'KYC / KYB Verification',
      icon: ShieldCheck,
      badge: systemStats.pendingKybReviews > 0 ? systemStats.pendingKybReviews : undefined,
      badgeColor: 'text-amber-400',
    },
    {
      id: 'reconciliation',
      label: 'Bank Reconciliation (BAI2)',
      icon: FileSpreadsheet,
      badge: systemStats.unreconciledExceptions > 0 ? systemStats.unreconciledExceptions : undefined,
      badgeColor: 'text-rose-400',
    },
    { id: 'treasury', label: 'Multi-Currency & Treasury', icon: Globe2 },
  ];

  const platformNav: { id: NavigationTab; label: string; icon: React.ElementType }[] = [
    { id: 'whitelabel', label: 'White-Label Portal Studio', icon: Sliders },
    { id: 'developer', label: 'API Explorer & Webhooks', icon: Terminal },
  ];

  return (
    <aside className="w-64 shrink-0 border-r border-slate-800 bg-[#0a0f18] flex flex-col justify-between p-4 min-h-[calc(100vh-4rem)]">
      <div className="space-y-6">
        {/* Active Tenant Card */}
        <div className="rounded border border-slate-800 bg-slate-900/60 p-3">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="flex items-center gap-1.5 font-medium">
              <Building2 className="h-3.5 w-3.5 text-indigo-400" />
              SaaS Tenant
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              {activeTenant.slug}
            </span>
          </div>
          <div className="font-semibold text-slate-100 text-sm truncate">
            {activeTenant.name}
          </div>
          <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>Take Rate:</span>
            <span className="font-mono text-slate-200">
              {(activeTenant.takeRateBps / 100).toFixed(2)}% + ${(activeTenant.flatFeeCents / 100).toFixed(2)}
            </span>
          </div>
          <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
            <span>Statement:</span>
            <span className="font-mono text-slate-300 truncate max-w-[120px]">
              {activeTenant.statementDescriptor}
            </span>
          </div>
        </div>

        {/* Section 1: Payment Rails & Core */}
        <div>
          <div className="px-2 mb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            Infrastructure Core
          </div>
          <div className="space-y-1">
            {coreNav.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded transition-colors text-left ${
                    isActive
                      ? 'bg-slate-800 text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <item.icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className={`text-[11px] font-mono font-semibold ${item.badgeColor || 'text-slate-300'}`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 2: Platform Customization */}
        <div>
          <div className="px-2 mb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            Platform & Developer
          </div>
          <div className="space-y-1">
            {platformNav.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded transition-colors text-left ${
                    isActive
                      ? 'bg-slate-800 text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <item.icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Network Rails Telemetry */}
      <div className="mt-6 pt-4 border-t border-slate-800/80 space-y-2.5">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 flex items-center justify-between">
          <span>Clearing Rails Status</span>
          <span className="flex items-center gap-1 text-emerald-400 text-[10px] font-normal lowercase">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            operational
          </span>
        </div>

        <div className="space-y-1.5 text-[11px] font-mono">
          <div className="flex items-center justify-between text-slate-400">
            <span>FedNow Direct</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" /> 24/7/365
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>TCH RTP</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" /> Instant
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>Same-Day ACH</span>
            <span className="text-slate-300">Cut-off 17:00 EST</span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>SEPA Instant</span>
            <span className="text-emerald-400">SCT Inst active</span>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-slate-800/50 flex items-center justify-between text-[11px] text-slate-400">
          <span>Mode:</span>
          <span className="font-mono text-slate-300 capitalize">{environment} Rails</span>
        </div>
      </div>
    </aside>
  );
};
