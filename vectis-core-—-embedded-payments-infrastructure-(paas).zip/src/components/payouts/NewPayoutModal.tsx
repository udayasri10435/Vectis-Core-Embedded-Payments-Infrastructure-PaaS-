import React, { useState } from 'react';
import { usePayments } from '../../context/PaymentsContext';
import { PaymentRail, Currency } from '../../types';
import {
  X,
  Zap,
  ArrowRight,
  ShieldCheck,
  Building2,
  Clock,
  CheckCircle2,
  Copy,
  Check,
} from 'lucide-react';

interface NewPayoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewPayoutModal: React.FC<NewPayoutModalProps> = ({ isOpen, onClose }) => {
  const { tenantMerchants, activeTenant, createPayout } = usePayments();

  const [selectedMerchantId, setSelectedMerchantId] = useState(
    tenantMerchants[0]?.id || ''
  );
  const [amount, setAmount] = useState<string>('2450.00');
  const [currency, setCurrency] = useState<Currency>('USD');
  const [rail, setRail] = useState<PaymentRail>('fednow');
  const [purpose, setPurpose] = useState<string>('Bi-weekly contractor service settlement');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [settledResult, setSettledResult] = useState<{
    id: string;
    traceNumber: string;
    settledAt: string;
    amount: number;
    platformFee: number;
    railFee: number;
    recipientBank: string;
  } | null>(null);

  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentMerchant = tenantMerchants.find((m) => m.id === selectedMerchantId) || tenantMerchants[0];

  const parsedAmount = parseFloat(amount) || 0;
  const platformFee = Number(((parsedAmount * (activeTenant.takeRateBps / 10000)) + (activeTenant.flatFeeCents / 100)).toFixed(2));
  const railFee = rail === 'fednow' ? 0.45 : rail === 'rtp' ? 0.35 : rail === 'swift_wire' ? 15.0 : 0.25;
  const netDisbursed = Math.max(0, parsedAmount - platformFee);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (parsedAmount <= 0) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const payout = createPayout({
        merchantId: selectedMerchantId,
        amount: parsedAmount,
        currency,
        rail,
        purpose,
      });

      setSettledResult({
        id: payout.id,
        traceNumber: payout.traceNumber,
        settledAt: payout.settledAt || new Date().toISOString(),
        amount: payout.amount,
        platformFee: payout.platformFee,
        railFee: payout.railsNetworkFee,
        recipientBank: payout.recipientBank,
      });
      setIsSubmitting(false);
    }, 600);
  };

  const handleCopyTrace = () => {
    if (settledResult) {
      navigator.clipboard.writeText(settledResult.traceNumber);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  const handleReset = () => {
    setSettledResult(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
      <div className="w-full max-w-xl rounded-lg border border-slate-700 bg-[#0e1626] shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded bg-indigo-600/30 text-indigo-400">
              <Zap className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-slate-100">
                Dispatch Real-Time Payout
              </h3>
              <p className="text-xs text-slate-400">
                Direct bank rail routing via {activeTenant.name}
              </p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="text-slate-400 hover:text-slate-200 transition-colors p-1"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {settledResult ? (
          /* Payout Receipt State */
          <div className="p-6 space-y-5">
            <div className="rounded border border-emerald-500/30 bg-emerald-950/20 p-4 text-center">
              <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400 mb-2">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <h4 className="text-base font-semibold text-emerald-300">
                Payment Settled via {rail.toUpperCase()}
              </h4>
              <p className="text-xs text-emerald-400/80 mt-0.5">
                Funds cleared directly in receiver FedReserve / RDFI account
              </p>
            </div>

            <div className="space-y-2.5 rounded border border-slate-800 bg-slate-900/60 p-4 text-xs font-mono">
              <div className="flex justify-between items-center text-slate-400">
                <span>Transaction Ref:</span>
                <span className="text-slate-200 font-semibold">{settledResult.id}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Fed / Clearing Trace:</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-indigo-300 truncate max-w-[200px]">
                    {settledResult.traceNumber}
                  </span>
                  <button
                    onClick={handleCopyTrace}
                    className="text-slate-400 hover:text-slate-200"
                    title="Copy Trace"
                  >
                    {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  </button>
                </div>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Recipient Institution:</span>
                <span className="text-slate-200">{settledResult.recipientBank}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Gross Settlement Amount:</span>
                <span className="text-slate-100 font-semibold">
                  ${settledResult.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })} {currency}
                </span>
              </div>
              <div className="flex justify-between items-center text-slate-400 border-t border-slate-800 pt-2">
                <span>Platform Take-Rate Revenue:</span>
                <span className="text-emerald-400 font-semibold">+${settledResult.platformFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Vectis Rails Network Cost:</span>
                <span className="text-slate-300">${settledResult.railFee.toFixed(2)}</span>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-indigo-400 shrink-0" />
              <span>
                Immutable double-entry journal lines posted to FBO Custodial Liability (2010) and Settlement Asset (1010).
              </span>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={handleReset}
                className="w-full rounded bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* Form State */
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {/* Merchant Select */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Sub-Merchant / Payee
              </label>
              <select
                value={selectedMerchantId}
                onChange={(e) => setSelectedMerchantId(e.target.value)}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-slate-100 outline-none focus:border-indigo-500"
              >
                {tenantMerchants.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.legalBusinessName} ({m.bankAccount.bankName} {m.bankAccount.accountNumberMasked}) - Avail: ${m.balanceUsd.toLocaleString()}
                  </option>
                ))}
              </select>
            </div>

            {/* Amount & Currency */}
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Gross Payout Amount
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-xs font-mono text-slate-400">
                    $
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 pl-7 pr-3 py-1.5 text-xs font-mono text-slate-100 outline-none focus:border-indigo-500"
                    placeholder="0.00"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Currency
                </label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as Currency)}
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-slate-100 outline-none focus:border-indigo-500"
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                </select>
              </div>
            </div>

            {/* Payment Rail Selector */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Payment Clearing Rail
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setRail('fednow')}
                  className={`flex flex-col p-2.5 rounded border text-left transition-colors ${
                    rail === 'fednow'
                      ? 'border-indigo-500 bg-indigo-950/40 text-white'
                      : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-semibold text-slate-200">FedNow Service</span>
                    <span className="text-[10px] font-mono text-emerald-400">~1.4s</span>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5">
                    Direct Federal Reserve 24/7/365 ($0.45 fee)
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setRail('rtp')}
                  className={`flex flex-col p-2.5 rounded border text-left transition-colors ${
                    rail === 'rtp'
                      ? 'border-indigo-500 bg-indigo-950/40 text-white'
                      : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-semibold text-slate-200">The Clearing House (RTP)</span>
                    <span className="text-[10px] font-mono text-emerald-400">~2.8s</span>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5">
                    Real-time payment network ($0.35 fee)
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setRail('ach_same_day')}
                  className={`flex flex-col p-2.5 rounded border text-left transition-colors ${
                    rail === 'ach_same_day'
                      ? 'border-indigo-500 bg-indigo-950/40 text-white'
                      : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-semibold text-slate-200">Same-Day ACH</span>
                    <span className="text-[10px] font-mono text-slate-400">~4 hrs</span>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5">
                    NACHA 17:00 settlement window ($0.25 fee)
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setRail('swift_wire')}
                  className={`flex flex-col p-2.5 rounded border text-left transition-colors ${
                    rail === 'swift_wire'
                      ? 'border-indigo-500 bg-indigo-950/40 text-white'
                      : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-semibold text-slate-200">Fedwire / SWIFT</span>
                    <span className="text-[10px] font-mono text-amber-400">Same-Day</span>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5">
                    High-value gross settlement ($15.00 fee)
                  </span>
                </button>
              </div>
            </div>

            {/* Purpose */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Statement Memo / Purpose
              </label>
              <input
                type="text"
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-slate-100 outline-none focus:border-indigo-500"
                placeholder="e.g. Weekly contractor progress draw"
              />
            </div>

            {/* Fee & Split Breakdown */}
            <div className="rounded border border-slate-800 bg-slate-900/80 p-3 space-y-1.5 text-xs font-mono">
              <div className="flex justify-between text-slate-400">
                <span>Requested Gross Amount:</span>
                <span className="text-slate-200 font-semibold">${parsedAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>SaaS Platform Revenue (Take Rate):</span>
                <span className="text-emerald-400 font-semibold">-${platformFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Network Rail Clearing Fee:</span>
                <span className="text-slate-300">-${railFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400 border-t border-slate-800 pt-1.5">
                <span>Recipient Net Deposit:</span>
                <span className="text-slate-100 font-bold">${netDisbursed.toFixed(2)}</span>
              </div>
            </div>

            {/* Submit Action */}
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="rounded border border-slate-700 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || parsedAmount <= 0}
                className="flex items-center gap-1.5 rounded bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <span className="h-3 w-3 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
                    <span>Routing to FedNow...</span>
                  </>
                ) : (
                  <>
                    <Zap className="h-3.5 w-3.5" />
                    <span>Disburse ${parsedAmount.toFixed(2)}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
