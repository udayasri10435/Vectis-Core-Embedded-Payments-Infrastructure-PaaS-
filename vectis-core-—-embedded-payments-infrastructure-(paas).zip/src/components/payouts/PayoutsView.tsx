import React, { useState, useMemo } from 'react';
import { usePayments } from '../../context/PaymentsContext';
import { PayoutTransaction, PaymentRail } from '../../types';
import {
  Zap,
  ArrowRightLeft,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  ArrowUpRight,
  ShieldCheck,
  Building2,
  Copy,
  Check,
  ExternalLink,
  ChevronRight,
  Info,
} from 'lucide-react';

export const PayoutsView: React.FC<{ onNewPayoutClick: () => void }> = ({ onNewPayoutClick }) => {
  const { payouts, tenantPayouts, activeTenant, setActiveTab } = usePayments();

  const [selectedRailFilter, setSelectedRailFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPayout, setSelectedPayout] = useState<PayoutTransaction | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredPayouts = useMemo(() => {
    return tenantPayouts.filter((p) => {
      const matchesRail =
        selectedRailFilter === 'all' || p.rail === selectedRailFilter;
      const matchesQuery =
        p.merchantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.traceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.purpose.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesRail && matchesQuery;
    });
  }, [tenantPayouts, selectedRailFilter, searchQuery]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const getRailBadge = (rail: PaymentRail) => {
    switch (rail) {
      case 'fednow':
        return (
          <span className="text-emerald-400 font-mono font-medium text-xs">
            FedNow 24/7
          </span>
        );
      case 'rtp':
        return (
          <span className="text-blue-400 font-mono font-medium text-xs">
            RTP Instant
          </span>
        );
      case 'ach_same_day':
        return (
          <span className="text-indigo-300 font-mono font-medium text-xs">
            Same-Day ACH
          </span>
        );
      case 'ach_standard':
        return (
          <span className="text-slate-400 font-mono font-medium text-xs">
            Standard ACH
          </span>
        );
      case 'sepa_instant':
        return (
          <span className="text-purple-300 font-mono font-medium text-xs">
            SEPA Instant
          </span>
        );
      case 'swift_wire':
        return (
          <span className="text-amber-400 font-mono font-medium text-xs">
            SWIFT Wire
          </span>
        );
      default:
        return <span className="font-mono text-xs">{rail}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Primary CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Payout Rails & Disbursements
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time execution across FedNow, RTP, NACHA Same-Day ACH, and European SEPA Instant.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onNewPayoutClick}
            className="flex items-center gap-1.5 rounded bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 transition-colors"
          >
            <Zap className="h-3.5 w-3.5" />
            <span>Dispatch Real-Time Payout</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400 font-medium">30-Day Disbursed Volume</div>
          <div className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-100">
            ${(activeTenant.payoutVolume30d).toLocaleString()}
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center gap-1.5">
            <span>Avg clearing: <strong className="text-emerald-400 font-mono">1.4s (FedNow)</strong></span>
          </div>
        </div>

        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400 font-medium">SaaS Take-Rate Yield</div>
          <div className="mt-1 text-xl font-bold font-mono tabular-nums text-emerald-400">
            ${((activeTenant.payoutVolume30d * (activeTenant.takeRateBps / 10000))).toLocaleString('en-US', { maximumFractionDigits: 0 })}
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            <span>Effective rate: {(activeTenant.takeRateBps / 100).toFixed(2)}% + ${ (activeTenant.flatFeeCents / 100).toFixed(2) }</span>
          </div>
        </div>

        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400 font-medium">Settlement Success Rate</div>
          <div className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-100">
            99.98%
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            <span>Zero returned transactions on instant rails</span>
          </div>
        </div>

        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="text-xs text-slate-400 font-medium">Clearing Cut-off Watch</div>
          <div className="mt-1 text-xl font-bold font-mono tabular-nums text-indigo-400">
            24/7/365
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            <span>FedNow/RTP uninterrupted liquidity</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Segmented Rail Controls */}
        <div className="flex items-center gap-1 p-1 bg-slate-900/80 rounded border border-slate-800 overflow-x-auto">
          {['all', 'fednow', 'rtp', 'ach_same_day', 'swift_wire'].map((railKey) => (
            <button
              key={railKey}
              onClick={() => setSelectedRailFilter(railKey)}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                selectedRailFilter === railKey
                  ? 'bg-slate-800 text-white shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {railKey === 'all'
                ? 'All Rails'
                : railKey === 'fednow'
                ? 'FedNow'
                : railKey === 'rtp'
                ? 'TCH RTP'
                : railKey === 'ach_same_day'
                ? 'Same-Day ACH'
                : 'Wire / SWIFT'}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative min-w-[280px]">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by merchant, trace ID, or memo..."
            className="w-full rounded border border-slate-800 bg-slate-900/90 pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-400 outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Main Payouts Table */}
      <div className="rounded border border-slate-800 bg-slate-900/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 font-medium">
                <th className="py-3 px-4">Transaction / Trace</th>
                <th className="py-3 px-4">Payee Merchant</th>
                <th className="py-3 px-4">Rail</th>
                <th className="py-3 px-4 text-right">Gross Amount</th>
                <th className="py-3 px-4 text-right">Platform Take</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredPayouts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 font-sans text-xs">
                    No payout records found matching your filters.
                  </td>
                </tr>
              ) : (
                filteredPayouts.map((payout) => (
                  <tr
                    key={payout.id}
                    onClick={() => setSelectedPayout(payout)}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                  >
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-200">{payout.id}</div>
                      <div className="text-[11px] text-slate-400 truncate max-w-[180px]">
                        {payout.traceNumber}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-sans">
                      <div className="font-medium text-slate-200">{payout.merchantName}</div>
                      <div className="text-[11px] text-slate-400">
                        {payout.recipientBank} · {payout.recipientAccountMasked}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {getRailBadge(payout.rail)}
                    </td>
                    <td className="py-3 px-4 text-right tabular-nums font-semibold text-slate-100">
                      ${payout.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-4 text-right tabular-nums text-emerald-400">
                      +${payout.platformFee.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 font-sans">
                      <div className="flex items-center gap-1.5 text-xs text-slate-300">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                        <span className="capitalize">{payout.status}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-400 text-[11px]">
                      {new Date(payout.initiatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </td>
                    <td className="py-3 px-4 text-right font-sans">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPayout(payout);
                        }}
                        className="text-indigo-400 hover:text-indigo-300 font-medium inline-flex items-center gap-1"
                      >
                        Inspect <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payout Details Drawer / Modal */}
      {selectedPayout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl rounded-lg border border-slate-700 bg-[#0e1626] shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
              <div className="flex items-center gap-2.5">
                <span className="flex h-7 w-7 items-center justify-center rounded bg-indigo-600/30 text-indigo-400 font-mono text-xs">
                  TX
                </span>
                <div>
                  <h3 className="text-sm font-semibold text-slate-100">
                    Payment Rail Audit: {selectedPayout.id}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono">
                    {selectedPayout.traceNumber}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPayout(null)}
                className="text-slate-400 hover:text-slate-200 transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-5 text-xs">
              {/* Top Overview */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 rounded border border-slate-800 bg-slate-900/60 p-4">
                <div>
                  <span className="text-slate-400 block text-[11px]">Clearing Rail</span>
                  <span className="font-semibold text-slate-200 uppercase mt-0.5 block font-mono">
                    {selectedPayout.rail}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Amount</span>
                  <span className="font-semibold text-slate-100 font-mono text-sm mt-0.5 block">
                    ${selectedPayout.amount.toFixed(2)} {selectedPayout.currency}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">SaaS Take-Rate</span>
                  <span className="font-semibold text-emerald-400 font-mono mt-0.5 block">
                    +${selectedPayout.platformFee.toFixed(2)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Network Rail Cost</span>
                  <span className="font-semibold text-slate-300 font-mono mt-0.5 block">
                    ${selectedPayout.railsNetworkFee.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* ISO 20022 Clearing Details */}
              <div className="space-y-2 rounded border border-slate-800 bg-slate-900/40 p-4 font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>ISO 20022 Schema ID:</span>
                  <span className="text-indigo-300">{selectedPayout.iso20022MessageId || 'pacs.008.001.08'}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Payee Organization:</span>
                  <span className="text-slate-200">{selectedPayout.merchantName}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Receiving RDFI Bank:</span>
                  <span className="text-slate-200">{selectedPayout.recipientBank}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Masked DDA Account:</span>
                  <span className="text-slate-200">{selectedPayout.recipientAccountMasked}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Business Purpose:</span>
                  <span className="text-slate-300">{selectedPayout.purpose}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Reconciliation Status:</span>
                  <span className={selectedPayout.reconciled ? 'text-emerald-400' : 'text-amber-400'}>
                    {selectedPayout.reconciled ? 'Reconciled to BAI2 / FedNow' : 'Pending End-of-Day File Match'}
                  </span>
                </div>
              </div>

              {/* Double-entry link note */}
              <div className="rounded border border-indigo-900/40 bg-indigo-950/20 p-3 flex items-start gap-2.5">
                <ShieldCheck className="h-4 w-4 text-indigo-400 shrink-0 mt-0.5" />
                <div className="text-[11px] text-indigo-200/90 leading-relaxed font-sans">
                  <strong>Double-Entry Ledger Verified:</strong> Debited Account 2010 (Sub-Merchant FBO Custodial Liability) and Credited Account 1010 (FedNow Master Settlement Asset) in real time.
                </div>
              </div>

              <div className="flex justify-between items-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedPayout(null);
                    setActiveTab('ledger');
                  }}
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
                >
                  View in Double-Entry Ledger →
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedPayout(null)}
                  className="rounded bg-slate-800 px-4 py-2 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Rail Comparison Benchmark: Vectis vs Stripe Connect vs Unit vs Increase */}
      <div className="rounded border border-slate-800 bg-slate-900/30 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">
              Payment Rail Architecture & Competitive Benchmark
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              How Vectis Core compares against legacy aggregators (Stripe Connect) and BaaS vendors (Unit, Increase).
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-medium">
                <th className="py-2.5 px-3">Infrastructure Feature</th>
                <th className="py-2.5 px-3 text-indigo-400 font-semibold">Vectis Core (This PaaS)</th>
                <th className="py-2.5 px-3">Stripe Connect</th>
                <th className="py-2.5 px-3">Unit</th>
                <th className="py-2.5 px-3">Increase</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 text-[11px] text-slate-300">
              <tr>
                <td className="py-2.5 px-3 font-medium">Direct FedNow 24/7/365</td>
                <td className="py-2.5 px-3 text-emerald-400 font-mono font-medium">Native Direct ($0.45 flat)</td>
                <td className="py-2.5 px-3 text-slate-400">Limited / 1.5% Instant card push</td>
                <td className="py-2.5 px-3 text-slate-300">Via Partner Bank (~$0.75)</td>
                <td className="py-2.5 px-3 text-slate-300">Native FedNow ($0.50)</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-medium">White-Label Freedom</td>
                <td className="py-2.5 px-3 text-emerald-400 font-medium">100% White-Label (Custom domain/CSS)</td>
                <td className="py-2.5 px-3 text-slate-400">Co-branded Stripe UI required</td>
                <td className="py-2.5 px-3 text-slate-300">White-label API</td>
                <td className="py-2.5 px-3 text-slate-300">Pure API only (no embedded widgets)</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-medium">Double-Entry Ledger</td>
                <td className="py-2.5 px-3 text-emerald-400 font-medium">Immutable double-entry core built-in</td>
                <td className="py-2.5 px-3 text-slate-400">Black-box balance ledger</td>
                <td className="py-2.5 px-3 text-slate-300">Bookkeeping add-on</td>
                <td className="py-2.5 px-3 text-slate-300">Internal ledger API</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-medium">Automated Bank Reconciliation</td>
                <td className="py-2.5 px-3 text-emerald-400 font-medium">3-Way BAI2 / CAMT.053 matching</td>
                <td className="py-2.5 px-3 text-slate-400">Stripe Sigma ($$$ add-on)</td>
                <td className="py-2.5 px-3 text-slate-300">Bank file exports only</td>
                <td className="py-2.5 px-3 text-slate-300">Developer webhooks</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-medium">Multi-Currency Payouts</td>
                <td className="py-2.5 px-3 text-emerald-400 font-medium">USD, EUR (SEPA), GBP, CAD</td>
                <td className="py-2.5 px-3 text-slate-300">Supported (high FX markup ~2%)</td>
                <td className="py-2.5 px-3 text-slate-400">US-domestic only</td>
                <td className="py-2.5 px-3 text-slate-400">US-domestic only</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
