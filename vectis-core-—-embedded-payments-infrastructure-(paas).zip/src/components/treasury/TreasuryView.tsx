import React, { useState } from 'react';
import { usePayments } from '../../context/PaymentsContext';
import { Currency } from '../../types';
import {
  Globe2,
  ArrowRightLeft,
  CheckCircle2,
  TrendingUp,
  Landmark,
  ShieldCheck,
  RefreshCw,
  Copy,
  Check,
} from 'lucide-react';

export const TreasuryView: React.FC = () => {
  const { fxRates, executeFxConversion, ledgerAccounts, activeTenant } = usePayments();

  const [fromCurrency, setFromCurrency] = useState<Currency>('USD');
  const [toCurrency, setToCurrency] = useState<Currency>('EUR');
  const [swapAmount, setSwapAmount] = useState<string>('25000');
  const [isSwapping, setIsSwapping] = useState(false);
  const [swapResult, setSwapResult] = useState<{
    toAmount: number;
    rate: number;
    fee: number;
  } | null>(null);

  const [copiedIban, setCopiedIban] = useState<string | null>(null);

  const currentRateObj = fxRates.find(
    (r) => (r.from === fromCurrency && r.to === toCurrency) || (r.from === toCurrency && r.to === fromCurrency)
  );

  const rateValue = currentRateObj
    ? currentRateObj.from === fromCurrency
      ? currentRateObj.rate
      : 1 / currentRateObj.rate
    : 1.08;

  const parsedAmount = parseFloat(swapAmount) || 0;
  const estimatedReceived = parsedAmount * rateValue * (1 - 0.0015);

  const handleSwap = (e: React.FormEvent) => {
    e.preventDefault();
    if (parsedAmount <= 0) return;
    setIsSwapping(true);
    setTimeout(() => {
      const result = executeFxConversion(fromCurrency, toCurrency, parsedAmount);
      setSwapResult(result);
      setIsSwapping(false);
    }, 600);
  };

  const handleCopyIban = (iban: string) => {
    navigator.clipboard.writeText(iban);
    setCopiedIban(iban);
    setTimeout(() => setCopiedIban(null), 1500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Multi-Currency Treasury & Global Liquidity
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Cross-border settlement pools, real-time FX spot execution, and localized Virtual IBAN collections.
          </p>
        </div>
      </div>

      {/* Currency Vault Balances Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>USD Direct Reserve (FedNow)</span>
            <span className="font-mono text-emerald-400 font-semibold">USD</span>
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-100">
            $14,850,920.00
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Fed Master Direct · Instant RTGS
          </div>
        </div>

        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>EUR Correspondent Vault (SEPA)</span>
            <span className="font-mono text-indigo-400 font-semibold">EUR</span>
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-100">
            €4,180,400.00
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Deutsche Bank Frankfurt · SCT Inst
          </div>
        </div>

        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>GBP Liquidity Pool</span>
            <span className="font-mono text-blue-400 font-semibold">GBP</span>
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-100">
            £1,920,850.00
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Barclays London · Faster Payments
          </div>
        </div>

        <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Treasury Yield Sweep (ON RRP)</span>
            <span className="font-mono text-emerald-400 font-semibold">5.20% APY</span>
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-emerald-400">
            $22,500,000.00
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Overnight Reverse Repo Sweep active
          </div>
        </div>
      </div>

      {/* FX Spot Desk and Rates Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive FX Spot Conversion Desk */}
        <div className="lg:col-span-6 rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">
              FX Spot Execution Desk
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Instant interbank currency exchange with automated double-entry ledger settlement.
            </p>
          </div>

          <form onSubmit={handleSwap} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  You Sell
                </label>
                <select
                  value={fromCurrency}
                  onChange={(e) => setFromCurrency(e.target.value as Currency)}
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-slate-100 outline-none"
                >
                  <option value="USD">USD - US Dollar</option>
                  <option value="EUR">EUR - Euro</option>
                  <option value="GBP">GBP - British Pound</option>
                  <option value="CAD">CAD - Canadian Dollar</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  You Buy
                </label>
                <select
                  value={toCurrency}
                  onChange={(e) => setToCurrency(e.target.value as Currency)}
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-slate-100 outline-none"
                >
                  <option value="EUR">EUR - Euro</option>
                  <option value="USD">USD - US Dollar</option>
                  <option value="GBP">GBP - British Pound</option>
                  <option value="CAD">CAD - Canadian Dollar</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Sell Amount ({fromCurrency})
              </label>
              <input
                type="number"
                step="100"
                min="100"
                value={swapAmount}
                onChange={(e) => setSwapAmount(e.target.value)}
                className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-2 text-sm font-mono text-slate-100 outline-none focus:border-indigo-500"
                required
              />
            </div>

            {/* Live Pricing Breakdown */}
            <div className="rounded border border-slate-800 bg-slate-900/80 p-3 font-mono space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Interbank Spot Mid-Rate:</span>
                <span className="text-slate-200">1 {fromCurrency} = {rateValue.toFixed(4)} {toCurrency}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Vectis Core FX Spread:</span>
                <span className="text-emerald-400 font-semibold">15 bps (0.15%)</span>
              </div>
              <div className="flex justify-between text-slate-400 border-t border-slate-800 pt-1.5">
                <span>Est. Net Credit:</span>
                <span className="text-indigo-300 font-bold">
                  ~{estimatedReceived.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {toCurrency}
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSwapping || fromCurrency === toCurrency}
              className="w-full rounded bg-indigo-600 py-2.5 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors disabled:opacity-50 flex items-center justify-center gap-1.5"
            >
              <ArrowRightLeft className={`h-3.5 w-3.5 ${isSwapping ? 'animate-spin' : ''}`} />
              <span>{isSwapping ? 'Executing Spot Swap...' : `Convert ${parsedAmount.toLocaleString()} ${fromCurrency} to ${toCurrency}`}</span>
            </button>
          </form>

          {swapResult && (
            <div className="rounded border border-emerald-500/30 bg-emerald-950/20 p-3 text-xs font-mono space-y-1 text-emerald-300">
              <div className="flex items-center gap-1.5 font-semibold">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span>Conversion Settled Instantly</span>
              </div>
              <div>Credited: +{swapResult.toAmount.toLocaleString()} {toCurrency}</div>
              <div className="text-[11px] text-emerald-400/80">Posted to double-entry ledger journal lines.</div>
            </div>
          )}
        </div>

        {/* Right: Live FX Rates Board */}
        <div className="lg:col-span-6 rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">
              Real-Time FX Feeds & Spreads
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Direct institutional pricing with fixed platform margin.
            </p>
          </div>

          <div className="divide-y divide-slate-800 rounded border border-slate-800 bg-slate-900/60 overflow-hidden text-xs">
            {fxRates.map((rate) => (
              <div key={rate.pair} className="p-3.5 flex items-center justify-between">
                <div>
                  <div className="font-mono font-bold text-slate-100 text-sm">
                    {rate.pair}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    Spread: {rate.spreadBps} bps · T+0 Settlement
                  </div>
                </div>

                <div className="text-right font-mono">
                  <div className="text-base font-bold text-slate-200 tabular-nums">
                    {rate.rate.toFixed(4)}
                  </div>
                  <div
                    className={`text-[11px] ${
                      rate.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {rate.change24h >= 0 ? '+' : ''}
                    {(rate.change24h * 100).toFixed(2)}%
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="rounded border border-indigo-900/30 bg-indigo-950/20 p-3.5 text-xs space-y-1">
            <span className="font-semibold text-indigo-300 block">
              Multi-Currency Sub-Merchant Virtual IBANs
            </span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Your platform sub-merchants can receive local European transfers via dedicated German / French IBANs (`DE89...`) and UK Faster Payments (`Sort Code 20-00-00`) without overseas legal incorporation.
            </p>
          </div>
        </div>
      </div>

      {/* Global Virtual Accounts Showcase */}
      <div className="rounded border border-slate-800 bg-slate-900/30 p-5 space-y-3">
        <h3 className="text-sm font-semibold text-slate-200">
          Platform Virtual Settlement Routing Details
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
          <div className="rounded border border-slate-800 bg-slate-900/70 p-3 space-y-1.5">
            <div className="text-slate-400 text-[11px]">US Dollar (FedNow / Fedwire)</div>
            <div className="text-slate-200 font-semibold">ABA Routing: 111000614</div>
            <div className="text-slate-300">Account: 9021-4819-2041</div>
            <div className="text-[10px] text-emerald-400 font-sans">Federal Reserve Direct Participant</div>
          </div>

          <div className="rounded border border-slate-800 bg-slate-900/70 p-3 space-y-1.5">
            <div className="text-slate-400 text-[11px]">Eurozone (SEPA Instant)</div>
            <div className="text-slate-200 font-semibold truncate">IBAN: DE89 3704 0044 0532 0130 00</div>
            <div className="text-slate-300">BIC / SWIFT: DEUTDEDDFXX</div>
            <div className="text-[10px] text-emerald-400 font-sans">TARGET2 / TIPS Participant</div>
          </div>

          <div className="rounded border border-slate-800 bg-slate-900/70 p-3 space-y-1.5">
            <div className="text-slate-400 text-[11px]">United Kingdom (Faster Payments)</div>
            <div className="text-slate-200 font-semibold">Sort Code: 20-04-15</div>
            <div className="text-slate-300">Account Number: 83920194</div>
            <div className="text-[10px] text-emerald-400 font-sans">Bank of England CHAPS / FPS</div>
          </div>
        </div>
      </div>
    </div>
  );
};
