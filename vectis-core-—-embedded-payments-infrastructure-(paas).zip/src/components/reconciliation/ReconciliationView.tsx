import React, { useState } from 'react';
import { usePayments } from '../../context/PaymentsContext';
import { ReconciliationBatch, ReconciliationDiscrepancy } from '../../types';
import {
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Search,
  ArrowRight,
  ShieldCheck,
  Building2,
  FileCheck2,
  Clock,
  ExternalLink,
} from 'lucide-react';

export const ReconciliationView: React.FC = () => {
  const {
    reconBatches,
    discrepancies,
    runAutoReconcile,
    resolveDiscrepancy,
    systemStats,
  } = usePayments();

  const [selectedBatchId, setSelectedBatchId] = useState<string>(
    reconBatches[1]?.id || reconBatches[0]?.id
  );
  const [isReconciling, setIsReconciling] = useState(false);
  const [resolutionNote, setResolutionNote] = useState('');
  const [selectedDiscrepancy, setSelectedDiscrepancy] = useState<ReconciliationDiscrepancy | null>(null);

  const selectedBatch =
    reconBatches.find((b) => b.id === selectedBatchId) || reconBatches[0];

  const batchDiscrepancies = discrepancies.filter(
    (d) => d.batchId === selectedBatchId
  );

  const handleRunReconcile = () => {
    setIsReconciling(true);
    setTimeout(() => {
      runAutoReconcile(selectedBatchId);
      setIsReconciling(false);
    }, 800);
  };

  const handleResolve = (dId: string) => {
    resolveDiscrepancy(dId, resolutionNote || 'Cleared via manual audit match.');
    setSelectedDiscrepancy(null);
    setResolutionNote('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Automated Bank Reconciliation Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Continuous 3-Way settlement matching across Internal Ledgers, FedNow / Clearing files, and Bank BAI2 / CAMT.053 statements.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRunReconcile}
            disabled={isReconciling || selectedBatch?.status === 'balanced'}
            className="flex items-center gap-1.5 rounded bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 transition-colors disabled:opacity-50"
          >
            <RotateCw className={`h-3.5 w-3.5 ${isReconciling ? 'animate-spin' : ''}`} />
            <span>{isReconciling ? 'Running 3-Way Match...' : 'Execute Auto-Reconciliation'}</span>
          </button>
        </div>
      </div>

      {/* 3-Way Match Architecture Banner */}
      <div className="rounded border border-slate-800 bg-slate-900/50 p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="rounded border border-slate-800 bg-slate-900/80 p-3">
            <div className="text-[10px] font-mono text-indigo-400 font-semibold uppercase">Leg 1 · Internal Book</div>
            <div className="font-semibold text-slate-100 text-sm mt-0.5">Double-Entry Ledger Core</div>
            <div className="text-[11px] text-slate-400 mt-1">
              Account 1010/1020 journal credit entries from platform payouts.
            </div>
          </div>

          <div className="rounded border border-slate-800 bg-slate-900/80 p-3">
            <div className="text-[10px] font-mono text-emerald-400 font-semibold uppercase">Leg 2 · Clearing Rail</div>
            <div className="font-semibold text-slate-100 text-sm mt-0.5">FedNow & RTP ISO 20022</div>
            <div className="text-[11px] text-slate-400 mt-1">
              Real-time pacs.002 acknowledgment files & Federal Reserve confirmation receipts.
            </div>
          </div>

          <div className="rounded border border-slate-800 bg-slate-900/80 p-3">
            <div className="text-[10px] font-mono text-blue-400 font-semibold uppercase">Leg 3 · Settlement Bank</div>
            <div className="font-semibold text-slate-100 text-sm mt-0.5">BAI2 & CAMT.053 Ingestion</div>
            <div className="text-[11px] text-slate-400 mt-1">
              Daily partner bank clearing statements & NACHA 98 control total matching.
            </div>
          </div>
        </div>
      </div>

      {/* Batches Table & Selected Discrepancy Split */}
      <div className="space-y-4">
        <h2 className="text-sm font-semibold text-slate-200">
          Daily Clearing Batches & Settlement Runs
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {reconBatches.map((batch) => {
            const isSelected = selectedBatchId === batch.id;
            const isBalanced = batch.status === 'balanced';
            return (
              <div
                key={batch.id}
                onClick={() => setSelectedBatchId(batch.id)}
                className={`rounded border p-4 cursor-pointer transition-all ${
                  isSelected
                    ? 'border-indigo-500 bg-slate-900/90 shadow-sm'
                    : 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-semibold text-slate-200">
                    {batch.settlementDate}
                  </span>
                  <span
                    className={`text-[10px] font-mono font-medium flex items-center gap-1 ${
                      isBalanced ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isBalanced ? (
                      <>
                        <CheckCircle2 className="h-3 w-3" /> Balanced ($0.00)
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="h-3 w-3" /> {batch.exceptionsCount} Exceptions
                      </>
                    )}
                  </span>
                </div>

                <div className="mt-2 text-xs text-slate-300 font-medium">
                  {batch.clearingFileFormat} · {batch.railSource.toUpperCase()}
                </div>

                <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono tabular-nums text-slate-400">
                  <span>Matched: {batch.matchedCount}/{batch.internalTransactionsCount}</span>
                  <span className="text-slate-100 font-bold">
                    ${batch.internalTotalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Discrepancy & Exceptions Management */}
      <div className="rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">
              Settlement Exceptions & Variance Journal for Batch {selectedBatch?.id}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Unmatched records requiring research, timing float adjustments, or ACH return resolution.
            </p>
          </div>

          <div className="text-xs font-mono text-slate-300">
            Total Variance: <strong className={selectedBatch?.varianceAmount === 0 ? 'text-emerald-400' : 'text-rose-400'}>
              ${Math.abs(selectedBatch?.varianceAmount || 0).toFixed(2)}
            </strong>
          </div>
        </div>

        {batchDiscrepancies.length === 0 ? (
          <div className="rounded border border-emerald-500/20 bg-emerald-950/10 p-6 text-center">
            <CheckCircle2 className="h-6 w-6 text-emerald-400 mx-auto mb-1.5" />
            <div className="text-xs font-semibold text-emerald-300">
              Zero Unreconciled Discrepancies
            </div>
            <p className="text-[11px] text-emerald-400/80 mt-0.5">
              All 142 FedNow & RTP transactions balanced with 100% precision against bank settlement file.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800 rounded border border-slate-800 bg-slate-900/60 overflow-hidden text-xs">
            {batchDiscrepancies.map((disc) => (
              <div
                key={disc.id}
                className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-800/30"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-semibold text-slate-200">
                      {disc.traceNumber}
                    </span>
                    <span
                      className={`text-[10px] font-mono capitalize ${
                        disc.status === 'cleared' ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      · {disc.status}
                    </span>
                    <span className="text-slate-400 font-mono text-[10px]">
                      ({disc.reason.replace(/_/g, ' ')})
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 font-sans">
                    {disc.notes}
                  </p>
                </div>

                <div className="flex items-center gap-6">
                  <div className="text-right font-mono">
                    <div className="text-slate-400 text-[10px]">Variance Delta</div>
                    <div className="text-rose-400 font-bold tabular-nums">
                      -${Math.abs(disc.variance).toFixed(2)}
                    </div>
                  </div>

                  {disc.status !== 'cleared' && (
                    <button
                      onClick={() => setSelectedDiscrepancy(disc)}
                      className="rounded bg-slate-800 border border-slate-700 px-3 py-1.5 text-xs font-semibold text-indigo-300 hover:bg-slate-700 transition-colors whitespace-nowrap"
                    >
                      Resolve Exception
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Exception Resolution Modal */}
      {selectedDiscrepancy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-lg border border-slate-700 bg-[#0e1626] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-semibold text-slate-100">
                Resolve Settlement Discrepancy
              </h3>
              <button
                onClick={() => setSelectedDiscrepancy(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-xs font-mono rounded bg-slate-900/80 p-3 border border-slate-800">
              <div className="flex justify-between text-slate-400">
                <span>Trace Number:</span>
                <span className="text-slate-200">{selectedDiscrepancy.traceNumber}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Internal Book Amount:</span>
                <span className="text-slate-200">${selectedDiscrepancy.internalAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>External Cleared:</span>
                <span className="text-slate-200">${selectedDiscrepancy.externalAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Discrepancy Reason:</span>
                <span className="text-amber-400 capitalize">{selectedDiscrepancy.reason.replace(/_/g, ' ')}</span>
              </div>
            </div>

            <div className="text-xs">
              <label className="block text-slate-300 font-medium mb-1">
                Resolution Action Note
              </label>
              <textarea
                value={resolutionNote}
                onChange={(e) => setResolutionNote(e.target.value)}
                placeholder="e.g. Matched to next-day morning NACHA window. No capital loss."
                className="w-full rounded border border-slate-700 bg-slate-900 p-2.5 text-xs text-slate-100 outline-none focus:border-indigo-500 h-20"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 text-xs">
              <button
                type="button"
                onClick={() => setSelectedDiscrepancy(null)}
                className="rounded border border-slate-700 px-3 py-1.5 text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleResolve(selectedDiscrepancy.id)}
                className="rounded bg-indigo-600 px-4 py-1.5 font-semibold text-white hover:bg-indigo-500"
              >
                Clear & Post Adjusting Entry
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
