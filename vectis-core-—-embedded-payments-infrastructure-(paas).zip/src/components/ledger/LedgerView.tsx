import React, { useState, useMemo } from 'react';
import { usePayments } from '../../context/PaymentsContext';
import { LedgerAccount, JournalEntry, JournalLine, Currency } from '../../types';
import {
  BookOpenCheck,
  Plus,
  ShieldCheck,
  Search,
  Filter,
  ArrowRightLeft,
  ChevronDown,
  ChevronRight,
  AlertCircle,
  CheckCircle2,
  Trash2,
  X,
} from 'lucide-react';

export const LedgerView: React.FC = () => {
  const { ledgerAccounts, journalEntries, tenantJournalEntries, postJournalEntry, activeTenant } = usePayments();

  const [expandedEntryId, setExpandedEntryId] = useState<string | null>(journalEntries[0]?.id || null);
  const [filterType, setFilterType] = useState<string>('all');
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);

  // Invariant Math
  const totalAssets = useMemo(() => {
    return ledgerAccounts
      .filter((a) => a.type === 'asset' && a.currency === 'USD')
      .reduce((sum, a) => sum + a.balance, 0);
  }, [ledgerAccounts]);

  const totalLiabilities = useMemo(() => {
    return ledgerAccounts
      .filter((a) => a.type === 'liability' && a.currency === 'USD')
      .reduce((sum, a) => sum + a.balance, 0);
  }, [ledgerAccounts]);

  const totalEquityRevenue = useMemo(() => {
    return ledgerAccounts
      .filter((a) => (a.type === 'equity' || a.type === 'revenue') && a.currency === 'USD')
      .reduce((sum, a) => sum + a.balance, 0);
  }, [ledgerAccounts]);

  const balanceDelta = Math.abs(totalAssets - (totalLiabilities + totalEquityRevenue));
  const isEquationBalanced = balanceDelta < 1.0;

  const filteredEntries = useMemo(() => {
    if (filterType === 'all') return journalEntries;
    return journalEntries.filter((e) => e.referenceType === filterType);
  }, [journalEntries, filterType]);

  // Form State for Manual Journal Posting
  const [manualDescription, setManualDescription] = useState('Manual Liquidity Rebalance between FedNow & Clearing Asset');
  const [manualLines, setManualLines] = useState<JournalLine[]>([
    {
      accountId: 'acct_1010',
      accountCode: '1010',
      accountName: 'FedNow Master Settlement Asset',
      direction: 'debit',
      amount: 50000.0,
      currency: 'USD',
    },
    {
      accountId: 'acct_1020',
      accountCode: '1020',
      accountName: 'ODFI Commercial Clearing Asset (ACH / RTP)',
      direction: 'credit',
      amount: 50000.0,
      currency: 'USD',
    },
  ]);
  const [manualError, setManualError] = useState<string | null>(null);

  const manualDebits = manualLines
    .filter((l) => l.direction === 'debit')
    .reduce((s, l) => s + (Number(l.amount) || 0), 0);
  const manualCredits = manualLines
    .filter((l) => l.direction === 'credit')
    .reduce((s, l) => s + (Number(l.amount) || 0), 0);
  const manualVariance = Math.abs(manualDebits - manualCredits);
  const canPostManual = manualVariance < 0.01 && manualDebits > 0;

  const handleAddManualLine = () => {
    setManualLines((prev) => [
      ...prev,
      {
        accountId: 'acct_2010',
        accountCode: '2010',
        accountName: 'Sub-Merchant FBO Custodial Liability',
        direction: 'credit',
        amount: 0,
        currency: 'USD',
      },
    ]);
  };

  const handleRemoveLine = (idx: number) => {
    if (manualLines.length <= 2) return;
    setManualLines((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleLineChange = (idx: number, updates: Partial<JournalLine>) => {
    setManualLines((prev) =>
      prev.map((line, i) => {
        if (i === idx) {
          const updated = { ...line, ...updates };
          if (updates.accountId) {
            const foundAcct = ledgerAccounts.find((a) => a.id === updates.accountId);
            if (foundAcct) {
              updated.accountCode = foundAcct.code;
              updated.accountName = foundAcct.name;
            }
          }
          return updated;
        }
        return line;
      })
    );
  };

  const handlePostManual = (e: React.FormEvent) => {
    e.preventDefault();
    setManualError(null);
    const result = postJournalEntry({
      description: manualDescription,
      referenceType: 'manual_adjustment',
      lines: manualLines.map((l) => ({ ...l, amount: Number(l.amount) })),
    });

    if (result.success) {
      setIsManualModalOpen(false);
    } else {
      setManualError(result.error || 'Failed to post entry');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Double-Entry Ledger & Chart of Accounts
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Immutable, zero-sum financial core. Debits and credits balance to zero on every transaction.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsManualModalOpen(true)}
            className="flex items-center gap-1.5 rounded bg-slate-800 border border-slate-700 px-3.5 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700 transition-colors"
          >
            <Plus className="h-3.5 w-3.5 text-indigo-400" />
            <span>Post Journal Entry</span>
          </button>
        </div>
      </div>

      {/* Accounting Invariant Verification Bar */}
      <div className="rounded border border-indigo-900/40 bg-indigo-950/20 p-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded bg-indigo-600/30 text-indigo-400">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                <span>Core Accounting Invariant:</span>
                <span className="font-mono text-indigo-300">
                  Assets = Liabilities + Equity & Revenue
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Every settlement, fee deduction, and reserve holdback balances to $0.00 across all accounts.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6 font-mono text-xs">
            <div>
              <span className="text-slate-400 text-[10px] block uppercase">Total Assets</span>
              <span className="text-emerald-400 font-bold tabular-nums">
                ${totalAssets.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <span className="text-slate-400 font-sans text-sm">=</span>
            <div>
              <span className="text-slate-400 text-[10px] block uppercase">Liabilities (FBO)</span>
              <span className="text-slate-200 font-bold tabular-nums">
                ${totalLiabilities.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <span className="text-slate-400 font-sans text-sm">+</span>
            <div>
              <span className="text-slate-400 text-[10px] block uppercase">Revenue / Yield</span>
              <span className="text-indigo-400 font-bold tabular-nums">
                ${totalEquityRevenue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Chart of Accounts Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-slate-200">
            Active Chart of Accounts
          </h2>
          <span className="text-[11px] text-slate-400">
            USD & Multi-Currency Custodial Vaults
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {ledgerAccounts.map((account) => {
            const isAsset = account.type === 'asset';
            const isRevenue = account.type === 'revenue';
            return (
              <div
                key={account.id}
                className="rounded border border-slate-800 bg-slate-900/50 p-4 space-y-2 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-indigo-400">
                    {account.code}
                  </span>
                  <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                    {account.type} · {account.normalBalance.toUpperCase()}
                  </span>
                </div>
                <div className="font-medium text-slate-200 text-xs">
                  {account.name}
                </div>
                <div className="text-base font-bold font-mono tabular-nums text-slate-100 pt-1">
                  {account.currency === 'USD' ? '$' : account.currency === 'EUR' ? '€' : '£'}
                  {account.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {account.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Journal Entries Stream */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">
              Immutable Journal Entries Stream
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Programmatic posting history with double-entry legs.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-900/80 rounded border border-slate-800 text-xs">
            {['all', 'payout', 'deposit_settlement', 'reserve_holdback', 'manual_adjustment'].map((t) => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className={`px-2.5 py-1 rounded transition-colors capitalize ${
                  filterType === t
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Entries Table */}
        <div className="rounded border border-slate-800 bg-slate-900/40 divide-y divide-slate-800">
          {filteredEntries.map((entry) => {
            const isExpanded = expandedEntryId === entry.id;
            const totalEntryDebits = entry.lines
              .filter((l) => l.direction === 'debit')
              .reduce((s, l) => s + l.amount, 0);

            return (
              <div key={entry.id} className="transition-colors">
                <div
                  onClick={() => setExpandedEntryId(isExpanded ? null : entry.id)}
                  className="flex items-center justify-between p-4 cursor-pointer hover:bg-slate-800/30"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-slate-400">
                      {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-semibold text-slate-200">
                          {entry.entryNumber}
                        </span>
                        <span className="text-slate-400 text-xs font-mono">
                          · {entry.referenceType}
                        </span>
                      </div>
                      <div className="text-xs text-slate-300 font-sans mt-0.5">
                        {entry.description}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 font-mono text-xs">
                    <div className="text-right">
                      <span className="text-slate-400 text-[10px] block">Sum Amount</span>
                      <span className="text-slate-100 font-bold tabular-nums">
                        ${totalEntryDebits.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div className="text-right text-[11px] text-slate-400 hidden sm:block">
                      <span>{new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      <div className="text-[10px] text-slate-400 truncate max-w-[120px]">{entry.postedBy}</div>
                    </div>
                  </div>
                </div>

                {/* Expanded Ledger Legs */}
                {isExpanded && (
                  <div className="bg-[#090d15] p-4 border-t border-slate-800/70">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="text-slate-400 border-b border-slate-800/60 pb-2">
                          <th className="py-1 px-3">Account Code</th>
                          <th className="py-1 px-3">Account Title</th>
                          <th className="py-1 px-3 text-right">Debit ($)</th>
                          <th className="py-1 px-3 text-right">Credit ($)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/30">
                        {entry.lines.map((line, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/50">
                            <td className="py-2 px-3 font-semibold text-indigo-400">
                              {line.accountCode}
                            </td>
                            <td className="py-2 px-3 text-slate-300 font-sans">
                              {line.accountName}
                            </td>
                            <td className="py-2 px-3 text-right tabular-nums font-semibold text-slate-200">
                              {line.direction === 'debit'
                                ? `$${line.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
                                : '—'}
                            </td>
                            <td className="py-2 px-3 text-right tabular-nums font-semibold text-slate-200">
                              {line.direction === 'credit'
                                ? `$${line.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
                                : '—'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Post Manual Entry Modal */}
      {isManualModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl rounded-lg border border-slate-700 bg-[#0e1626] shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
              <div className="flex items-center gap-2">
                <span className="flex h-7 w-7 items-center justify-center rounded bg-indigo-600/30 text-indigo-400">
                  <BookOpenCheck className="h-4 w-4" />
                </span>
                <div>
                  <h3 className="text-sm font-semibold text-slate-100">
                    Post Manual Double-Entry Journal
                  </h3>
                  <p className="text-xs text-slate-400">
                    Strict zero-sum validation enforced
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsManualModalOpen(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handlePostManual} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Journal Description / Memorandum
                </label>
                <input
                  type="text"
                  value={manualDescription}
                  onChange={(e) => setManualDescription(e.target.value)}
                  className="w-full rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-slate-100 outline-none focus:border-indigo-500"
                  required
                />
              </div>

              {/* Legs Table */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-300 font-medium">Accounting Legs</span>
                  <button
                    type="button"
                    onClick={handleAddManualLine}
                    className="text-indigo-400 hover:text-indigo-300 font-semibold"
                  >
                    + Add Leg
                  </button>
                </div>

                <div className="space-y-2">
                  {manualLines.map((line, idx) => (
                    <div
                      key={idx}
                      className="grid grid-cols-12 gap-2 items-center rounded border border-slate-800 bg-slate-900/60 p-2"
                    >
                      <div className="col-span-5">
                        <select
                          value={line.accountId}
                          onChange={(e) => handleLineChange(idx, { accountId: e.target.value })}
                          className="w-full rounded border border-slate-700 bg-slate-900 px-2 py-1 text-slate-200 text-xs"
                        >
                          {ledgerAccounts.map((a) => (
                            <option key={a.id} value={a.id}>
                              {a.code} - {a.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="col-span-3">
                        <select
                          value={line.direction}
                          onChange={(e) =>
                            handleLineChange(idx, {
                              direction: e.target.value as 'debit' | 'credit',
                            })
                          }
                          className="w-full rounded border border-slate-700 bg-slate-900 px-2 py-1 text-slate-200 text-xs uppercase font-mono font-medium"
                        >
                          <option value="debit">DEBIT</option>
                          <option value="credit">CREDIT</option>
                        </select>
                      </div>

                      <div className="col-span-3">
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={line.amount}
                          onChange={(e) =>
                            handleLineChange(idx, { amount: parseFloat(e.target.value) || 0 })
                          }
                          className="w-full rounded border border-slate-700 bg-slate-900 px-2 py-1 text-slate-100 font-mono text-xs"
                          placeholder="0.00"
                        />
                      </div>

                      <div className="col-span-1 text-center">
                        {manualLines.length > 2 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveLine(idx)}
                            className="text-slate-400 hover:text-rose-400"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Balance Verification Footer */}
              <div className="rounded border border-slate-800 bg-slate-900/80 p-3 font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Total Debits:</span>
                  <span className="text-slate-100 font-bold">${manualDebits.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Total Credits:</span>
                  <span className="text-slate-100 font-bold">${manualCredits.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-400 border-t border-slate-800 pt-1.5">
                  <span>Variance:</span>
                  <span
                    className={
                      canPostManual ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'
                    }
                  >
                    ${manualVariance.toFixed(2)} {canPostManual ? '(Balanced)' : '(Unbalanced)'}
                  </span>
                </div>
              </div>

              {manualError && (
                <div className="text-xs text-rose-400 flex items-center gap-1.5">
                  <AlertCircle className="h-4 w-4" />
                  <span>{manualError}</span>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsManualModalOpen(false)}
                  className="rounded border border-slate-700 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!canPostManual}
                  className="rounded bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors disabled:opacity-50"
                >
                  Commit Journal Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
