export type PaymentRail = 'fednow' | 'rtp' | 'ach_same_day' | 'ach_standard' | 'sepa_instant' | 'swift_wire';

export type Currency = 'USD' | 'EUR' | 'GBP' | 'CAD' | 'SGD' | 'JPY';

export interface VerticalTenant {
  id: string;
  name: string;
  slug: string;
  industry: string;
  brandColor: string;
  accentColor: string;
  logoText: string;
  subdomain: string;
  takeRateBps: number; // e.g. 40 = 0.40%
  flatFeeCents: number; // e.g. 35 = $0.35
  statementDescriptor: string;
  subMerchantCount: number;
  totalGtvUsd: number;
  payoutVolume30d: number;
  webhookUrl: string;
  status: 'active' | 'sandboxed' | 'onboarding';
  payoutMethodsAllowed: PaymentRail[];
  kybAutoApproveThreshold: number; // risk score threshold
}

export type SubMerchantOnboardingStatus = 'kyb_approved' | 'under_review' | 'action_required' | 'rejected';

export interface SubMerchant {
  id: string;
  tenantId: string;
  legalBusinessName: string;
  dba: string;
  ein: string;
  businessType: 'LLC' | 'C-Corp' | 'S-Corp' | 'Sole Proprietorship' | 'Partnership';
  website: string;
  beneficialOwner: {
    fullName: string;
    title: string;
    ownershipPct: number;
    ssnLast4: string;
    dob: string;
    email: string;
  };
  address: {
    street: string;
    city: string;
    state: string;
    zip: string;
    country: string;
  };
  onboardingStatus: SubMerchantOnboardingStatus;
  riskScore: number; // 0 (lowest risk) to 100 (highest risk)
  kycVerificationPassed: boolean;
  kybVerificationPassed: boolean;
  ofacScreeningClear: boolean;
  bankAccount: {
    bankName: string;
    routingNumber: string;
    accountNumberMasked: string;
    accountType: 'checking' | 'savings';
    supportedRails: PaymentRail[];
  };
  balanceUsd: number;
  balanceEur: number;
  balanceGbp: number;
  pendingPayoutsCount: number;
  createdAt: string;
}

export interface PayoutTransaction {
  id: string;
  tenantId: string;
  merchantId: string;
  merchantName: string;
  amount: number;
  currency: Currency;
  rail: PaymentRail;
  status: 'settled' | 'processing' | 'scheduled' | 'failed' | 'reversed';
  platformFee: number;
  railsNetworkFee: number;
  recipientAccountMasked: string;
  recipientBank: string;
  traceNumber: string; // FedReference or ACH Trace
  purpose: string;
  initiatedAt: string;
  settledAt?: string;
  iso20022MessageId?: string;
  reconciled: boolean;
}

export interface LedgerAccount {
  id: string;
  code: string;
  name: string;
  type: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  normalBalance: 'debit' | 'credit';
  currency: Currency;
  balance: number;
  description: string;
  subType: 'fbo_custodial' | 'clearing_settlement' | 'reserve_holdback' | 'fee_accrual' | 'operating';
}

export interface JournalLine {
  accountId: string;
  accountCode: string;
  accountName: string;
  direction: 'debit' | 'credit';
  amount: number;
  currency: Currency;
}

export interface JournalEntry {
  id: string;
  entryNumber: string;
  timestamp: string;
  description: string;
  referenceType: 'payout' | 'deposit_settlement' | 'fx_conversion' | 'platform_take' | 'reserve_holdback' | 'manual_adjustment';
  referenceId: string;
  tenantId: string;
  postedBy: string;
  lines: JournalLine[];
}

export interface KybCaseDocument {
  id: string;
  type: 'articles_of_inc' | 'ein_verification' | 'proof_of_address' | 'bank_voided_check' | 'owner_gov_id';
  name: string;
  fileSize: string;
  uploadedAt: string;
  status: 'verified' | 'unverified' | 'rejected';
}

export interface KybCase {
  id: string;
  tenantId: string;
  merchantId: string;
  legalBusinessName: string;
  dba: string;
  submittedAt: string;
  status: 'pending_review' | 'approved' | 'action_required' | 'rejected';
  riskScore: number;
  riskTier: 'low' | 'moderate' | 'elevated' | 'high';
  checks: {
    sosRegistration: { status: 'passed' | 'review' | 'failed'; detail: string };
    tinMatching: { status: 'passed' | 'review' | 'failed'; detail: string };
    fincenUboCheck: { status: 'passed' | 'review' | 'failed'; detail: string };
    ofacSanctions: { status: 'passed' | 'review' | 'failed'; detail: string };
    adverseMedia: { status: 'passed' | 'review' | 'failed'; detail: string };
    bankAccountAuth: { status: 'passed' | 'review' | 'failed'; detail: string };
  };
  documents: KybCaseDocument[];
  reviewerNotes: string[];
  beneficialOwnerName: string;
  businessAddress: string;
}

export interface ReconciliationBatch {
  id: string;
  settlementDate: string;
  railSource: PaymentRail | 'all_rails';
  clearingFileFormat: 'BAI2' | 'CAMT.053' | 'FedNow_ISO20022' | 'NACHA_98';
  internalTransactionsCount: number;
  externalRecordsCount: number;
  internalTotalAmount: number;
  externalTotalAmount: number;
  matchedCount: number;
  exceptionsCount: number;
  status: 'balanced' | 'exceptions_pending' | 'in_reconciliation';
  varianceAmount: number;
}

export interface ReconciliationDiscrepancy {
  id: string;
  batchId: string;
  transactionId?: string;
  traceNumber: string;
  internalAmount: number;
  externalAmount: number;
  variance: number;
  reason: 'timing_cutoff_lag' | 'bank_fee_deduction' | 'unrecognized_external_credit' | 'chargeback_reversal' | 'transit_float' | 'returned_ach';
  status: 'unresolved' | 'investigating' | 'cleared';
  notes: string;
}

export interface FxRate {
  pair: string; // e.g. "EUR/USD"
  from: Currency;
  to: Currency;
  rate: number;
  change24h: number;
  spreadBps: number;
}

export interface WebhookEvent {
  id: string;
  event: string; // e.g. "payout.settled", "kyb.approved", "ledger.entry_created"
  timestamp: string;
  tenantId: string;
  status: 'delivered' | 'retrying' | 'failed';
  httpStatus: number;
  payload: Record<string, unknown>;
  signature: string;
}
