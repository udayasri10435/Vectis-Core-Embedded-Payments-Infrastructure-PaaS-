import React, { useState } from 'react';
import { PaymentsProvider, usePayments } from './context/PaymentsContext';
import { TopHeader } from './components/layout/TopHeader';
import { Sidebar } from './components/layout/Sidebar';
import { OverviewView } from './components/dashboard/OverviewView';
import { PayoutsView } from './components/payouts/PayoutsView';
import { LedgerView } from './components/ledger/LedgerView';
import { ComplianceView } from './components/kyb/ComplianceView';
import { ReconciliationView } from './components/reconciliation/ReconciliationView';
import { TreasuryView } from './components/treasury/TreasuryView';
import { WhiteLabelStudio } from './components/whitelabel/WhiteLabelStudio';
import { DeveloperHub } from './components/developer/DeveloperHub';
import { NewPayoutModal } from './components/payouts/NewPayoutModal';

const AppContent: React.FC = () => {
  const { activeTab } = usePayments();
  const [isPayoutModalOpen, setIsPayoutModalOpen] = useState(false);

  const renderActiveView = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewView onNewPayoutClick={() => setIsPayoutModalOpen(true)} />;
      case 'payouts':
        return <PayoutsView onNewPayoutClick={() => setIsPayoutModalOpen(true)} />;
      case 'ledger':
        return <LedgerView />;
      case 'compliance':
        return <ComplianceView />;
      case 'reconciliation':
        return <ReconciliationView />;
      case 'treasury':
        return <TreasuryView />;
      case 'whitelabel':
        return <WhiteLabelStudio />;
      case 'developer':
        return <DeveloperHub />;
      default:
        return <OverviewView onNewPayoutClick={() => setIsPayoutModalOpen(true)} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col font-sans">
      {/* Top Header strictly conforming to Top Bar Contract */}
      <TopHeader onNewPayoutClick={() => setIsPayoutModalOpen(true)} />

      {/* Main Workspace Frame */}
      <div className="flex flex-1 overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar onNewPayoutClick={() => setIsPayoutModalOpen(true)} />

        {/* Viewport Canvas */}
        <main className="flex-1 overflow-y-auto p-6 lg:p-8 max-w-[1600px]">
          {renderActiveView()}
        </main>
      </div>

      {/* Modal for Dispatching Instant FedNow / RTP Payouts */}
      <NewPayoutModal
        isOpen={isPayoutModalOpen}
        onClose={() => setIsPayoutModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <PaymentsProvider>
      <AppContent />
    </PaymentsProvider>
  );
}
