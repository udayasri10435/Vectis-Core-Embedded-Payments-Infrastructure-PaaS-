import React, { createContext, useContext, useState, useMemo, ReactNode } from 'react';
import {
  VerticalTenant,
  SubMerchant,
  PayoutTransaction,
  LedgerAccount,
  JournalEntry,
  JournalLine,
  KybCase,
  ReconciliationBatch,
  ReconciliationDiscrepancy,
  FxRate,
  WebhookEvent,
  PaymentRail,
  Currency,
} from '../types';
import {
  INITIAL_TENANTS,
  INITIAL_MERCHANTS,
  INITIAL_LEDGER_ACCOUNTS,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_PAYOUTS,
  INITIAL_KYB_CASES,
  INITIAL_RECON_BATCHES,
  INITIAL_DISCREPANCIES,
  INITIAL_FX_RATES,
  INITIAL_WEBHOOKS,
} from '../data/mockData';

export type NavigationTab =
  | 'overview'
  | 'payouts'
  | 'ledger'
  | 'compliance'
  | 'reconciliation'
  | 'treasury'
  | 'whitelabel'
  | 'developer';

interface PaymentsContextType {
  environment: 'live' | 'sandbox';
  setEnvironment: (env: 'live' | 'sandbox') => void;
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  tenants: VerticalTenant[];
  selectedTenantId: string;
  setSelectedTenantId: (id: string) => void;
  activeTenant: VerticalTenant;
  updateTenant: (id: string, updates: Partial<VerticalTenant>) => void;
  
  merchants: SubMerchant[];
  tenantMerchants: SubMerchant[];
  addMerchant: (merchantData: Partial<SubMerchant>) => SubMerchant;
  
  payouts: PayoutTransaction[];
  tenantPayouts: PayoutTransaction[];
  createPayout: (params: {
    merchantId: string;
    amount: number;
    currency: Currency;
    rail: PaymentRail;
    purpose: string;
  }) => PayoutTransaction;
  
  ledgerAccounts: LedgerAccount[];
  journalEntries: JournalEntry[];
  tenantJournalEntries: JournalEntry[];
  postJournalEntry: (entry: {
    description: string;
    referenceType: JournalEntry['referenceType'];
    referenceId?: string;
    lines: JournalLine[];
  }) => { success: boolean; error?: string };
  
  kybCases: KybCase[];
  tenantKybCases: KybCase[];
  updateKybCaseStatus: (
    caseId: string,
    status: KybCase['status'],
    reviewerNote?: string
  ) => void;
  
  reconBatches: ReconciliationBatch[];
  discrepancies: ReconciliationDiscrepancy[];
  runAutoReconcile: (batchId: string) => void;
  resolveDiscrepancy: (id: string, notes?: string) => void;
  
  fxRates: FxRate[];
  executeFxConversion: (
    from: Currency,
    to: Currency,
    fromAmount: number
  ) => { toAmount: number; rate: number; fee: number };
  
  webhooks: WebhookEvent[];
  dispatchTestWebhook: (eventType: string, payload?: Record<string, unknown>) => void;
  
  // Quick metrics
  systemStats: {
    totalGtv: number;
    settledPayoutsToday: number;
    activeMerchants: number;
    ledgerBalanceUsd: number;
    unreconciledExceptions: number;
    pendingKybReviews: number;
  };
}

const PaymentsContext = createContext<PaymentsContextType | null>(null);

export const PaymentsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [environment, setEnvironment] = useState<'live' | 'sandbox'>('live');
  const [activeTab, setActiveTab] = useState<NavigationTab>('overview');
  
  const [tenants, setTenants] = useState<VerticalTenant[]>(INITIAL_TENANTS);
  const [selectedTenantId, setSelectedTenantId] = useState<string>('tenant_tradesflow');
  
  const [merchants, setMerchants] = useState<SubMerchant[]>(INITIAL_MERCHANTS);
  const [payouts, setPayouts] = useState<PayoutTransaction[]>(INITIAL_PAYOUTS);
  const [ledgerAccounts, setLedgerAccounts] = useState<LedgerAccount[]>(INITIAL_LEDGER_ACCOUNTS);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(INITIAL_JOURNAL_ENTRIES);
  const [kybCases, setKybCases] = useState<KybCase[]>(INITIAL_KYB_CASES);
  const [reconBatches, setReconBatches] = useState<ReconciliationBatch[]>(INITIAL_RECON_BATCHES);
  const [discrepancies, setDiscrepancies] = useState<ReconciliationDiscrepancy[]>(INITIAL_DISCREPANCIES);
  const [fxRates] = useState<FxRate[]>(INITIAL_FX_RATES);
  const [webhooks, setWebhooks] = useState<WebhookEvent[]>(INITIAL_WEBHOOKS);

  const activeTenant = useMemo(() => {
    return tenants.find((t) => t.id === selectedTenantId) || tenants[0];
  }, [tenants, selectedTenantId]);

  const tenantMerchants = useMemo(() => {
    return merchants.filter((m) => m.tenantId === selectedTenantId);
  }, [merchants, selectedTenantId]);

  const tenantPayouts = useMemo(() => {
    return payouts.filter((p) => p.tenantId === selectedTenantId);
  }, [payouts, selectedTenantId]);

  const tenantJournalEntries = useMemo(() => {
    return journalEntries.filter((je) => je.tenantId === selectedTenantId);
  }, [journalEntries, selectedTenantId]);

  const tenantKybCases = useMemo(() => {
    return kybCases.filter((c) => c.tenantId === selectedTenantId);
  }, [kybCases, selectedTenantId]);

  const updateTenant = (id: string, updates: Partial<VerticalTenant>) => {
    setTenants((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updates } : t))
    );
  };

  const addMerchant = (merchantData: Partial<SubMerchant>): SubMerchant => {
    const newMerchant: SubMerchant = {
      id: `subm_${Math.floor(10000 + Math.random() * 90000)}`,
      tenantId: selectedTenantId,
      legalBusinessName: merchantData.legalBusinessName || 'New Contractor LLC',
      dba: merchantData.dba || 'New Contractor LLC',
      ein: merchantData.ein || '99-0001234',
      businessType: merchantData.businessType || 'LLC',
      website: merchantData.website || 'https://example.com',
      beneficialOwner: merchantData.beneficialOwner || {
        fullName: 'Jordan Taylor',
        title: 'Managing Partner',
        ownershipPct: 100,
        ssnLast4: '9921',
        dob: '1988-04-12',
        email: 'jordan@example.com',
      },
      address: merchantData.address || {
        street: '100 Main Street',
        city: 'Austin',
        state: 'TX',
        zip: '78701',
        country: 'USA',
      },
      onboardingStatus: 'under_review',
      riskScore: Math.floor(10 + Math.random() * 25),
      kycVerificationPassed: true,
      kybVerificationPassed: false,
      ofacScreeningClear: true,
      bankAccount: merchantData.bankAccount || {
        bankName: 'JPMorgan Chase Bank, N.A.',
        routingNumber: '111000614',
        accountNumberMasked: '••••' + Math.floor(1000 + Math.random() * 9000),
        accountType: 'checking',
        supportedRails: ['fednow', 'rtp', 'ach_same_day', 'ach_standard'],
      },
      balanceUsd: 25000.0,
      balanceEur: 0,
      balanceGbp: 0,
      pendingPayoutsCount: 0,
      createdAt: new Date().toISOString(),
    };

    setMerchants((prev) => [newMerchant, ...prev]);

    // Also create KYB Case
    const newKybCase: KybCase = {
      id: `kyb_case_${Math.floor(1000 + Math.random() * 9000)}`,
      tenantId: selectedTenantId,
      merchantId: newMerchant.id,
      legalBusinessName: newMerchant.legalBusinessName,
      dba: newMerchant.dba,
      submittedAt: new Date().toISOString(),
      status: 'pending_review',
      riskScore: newMerchant.riskScore,
      riskTier: newMerchant.riskScore < 20 ? 'low' : 'moderate',
      beneficialOwnerName: `${newMerchant.beneficialOwner.fullName} (${newMerchant.beneficialOwner.ownershipPct}% UBO)`,
      businessAddress: `${newMerchant.address.street}, ${newMerchant.address.city}, ${newMerchant.address.state}`,
      checks: {
        sosRegistration: { status: 'passed', detail: 'State Registry validation automated confirmation.' },
        tinMatching: { status: 'passed', detail: 'IRS EIN format verified.' },
        fincenUboCheck: { status: 'review', detail: 'Single primary beneficial owner verified.' },
        ofacSanctions: { status: 'passed', detail: 'SDN screening verified zero sanctions hits.' },
        adverseMedia: { status: 'passed', detail: 'No adverse media detected.' },
        bankAccountAuth: { status: 'passed', detail: 'Bank account routing code verified active.' },
      },
      documents: [
        {
          id: `doc_${Date.now()}_1`,
          type: 'articles_of_inc',
          name: 'Articles_of_Organization.pdf',
          fileSize: '1.4 MB',
          uploadedAt: new Date().toISOString(),
          status: 'verified',
        },
        {
          id: `doc_${Date.now()}_2`,
          type: 'owner_gov_id',
          name: 'Passport_Scan.pdf',
          fileSize: '2.1 MB',
          uploadedAt: new Date().toISOString(),
          status: 'verified',
        },
      ],
      reviewerNotes: ['Direct onboarding through vertical SaaS white-label embedded portal.'],
    };

    setKybCases((prev) => [newKybCase, ...prev]);
    return newMerchant;
  };

  const createPayout = (params: {
    merchantId: string;
    amount: number;
    currency: Currency;
    rail: PaymentRail;
    purpose: string;
  }): PayoutTransaction => {
    const merchant = merchants.find((m) => m.id === params.merchantId);
    const merchantName = merchant ? merchant.legalBusinessName : 'Contractor';
    const recipientBank = merchant ? merchant.bankAccount.bankName : 'Commercial Partner Bank';
    const recipientAccount = merchant ? merchant.bankAccount.accountNumberMasked : '••••8821';

    // Compute fee
    const platformFee = Number(((params.amount * (activeTenant.takeRateBps / 10000)) + (activeTenant.flatFeeCents / 100)).toFixed(2));
    const railFee = params.rail === 'fednow' ? 0.45 : params.rail === 'rtp' ? 0.35 : params.rail === 'swift_wire' ? 15.0 : 0.25;

    const payoutId = `pay_${params.rail.slice(0, 3)}_${Math.floor(100000 + Math.random() * 900000)}`;
    const tracePrefix = params.rail === 'fednow' ? 'FEDNOW' : params.rail === 'rtp' ? 'RTP-TCH' : 'ACH-TR';
    const traceNumber = `${tracePrefix}-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100000000 + Math.random() * 900000000)}`;

    const newPayout: PayoutTransaction = {
      id: payoutId,
      tenantId: selectedTenantId,
      merchantId: params.merchantId,
      merchantName,
      amount: params.amount,
      currency: params.currency,
      rail: params.rail,
      status: 'settled',
      platformFee,
      railsNetworkFee: railFee,
      recipientAccountMasked: recipientAccount,
      recipientBank,
      traceNumber,
      purpose: params.purpose,
      initiatedAt: new Date().toISOString(),
      settledAt: new Date().toISOString(),
      iso20022MessageId: `pacs.008.001.08/${payoutId.toUpperCase()}`,
      reconciled: false,
    };

    setPayouts((prev) => [newPayout, ...prev]);

    // Update merchant balance
    setMerchants((prev) =>
      prev.map((m) =>
        m.id === params.merchantId
          ? {
              ...m,
              balanceUsd: Math.max(0, m.balanceUsd - params.amount),
              pendingPayoutsCount: m.pendingPayoutsCount + 1,
            }
          : m
      )
    );

    // Double-Entry Ledger Posting:
    // Debit: Sub-merchant FBO Custodial Liability (decreases liability owed to merchant)
    // Credit: FedNow Settlement Asset or Clearing Asset (decreases our bank asset as cash leaves rails)
    const clearingAccount = params.rail === 'fednow' ? 'acct_1010' : 'acct_1020';
    const clearingAccountName = params.rail === 'fednow' ? 'FedNow Master Settlement Asset' : 'ODFI Commercial Clearing Asset (ACH / RTP)';
    const clearingAccountCode = params.rail === 'fednow' ? '1010' : '1020';

    const newJournalLines: JournalLine[] = [
      {
        accountId: 'acct_2010',
        accountCode: '2010',
        accountName: 'Sub-Merchant FBO Custodial Liability',
        direction: 'debit',
        amount: params.amount,
        currency: params.currency,
      },
      {
        accountId: clearingAccount,
        accountCode: clearingAccountCode,
        accountName: clearingAccountName,
        direction: 'credit',
        amount: params.amount,
        currency: params.currency,
      },
    ];

    const newEntryNumber = `JE-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;
    const newJournalEntry: JournalEntry = {
      id: `je_${Date.now()}`,
      entryNumber: newEntryNumber,
      timestamp: new Date().toISOString(),
      description: `Automated Payout Disbursement: ${merchantName} (${params.rail.toUpperCase()})`,
      referenceType: 'payout',
      referenceId: payoutId,
      tenantId: selectedTenantId,
      postedBy: 'AUTONOMOUS_RAIL_DISPATCHER',
      lines: newJournalLines,
    };

    setJournalEntries((prev) => [newJournalEntry, ...prev]);

    // Update ledger balances
    setLedgerAccounts((prev) =>
      prev.map((acct) => {
        if (acct.id === 'acct_2010') {
          return { ...acct, balance: acct.balance - params.amount };
        }
        if (acct.id === clearingAccount) {
          return { ...acct, balance: acct.balance - params.amount };
        }
        return acct;
      })
    );

    // Dispatch webhook
    dispatchTestWebhook('payout.settled', {
      id: newPayout.id,
      amount: newPayout.amount,
      currency: newPayout.currency,
      rail: newPayout.rail,
      merchant_id: newPayout.merchantId,
      trace_number: newPayout.traceNumber,
      status: 'settled',
    });

    return newPayout;
  };

  const postJournalEntry = (entry: {
    description: string;
    referenceType: JournalEntry['referenceType'];
    referenceId?: string;
    lines: JournalLine[];
  }): { success: boolean; error?: string } => {
    // Invariant check: Debits must equal Credits
    const totalDebits = entry.lines
      .filter((l) => l.direction === 'debit')
      .reduce((sum, l) => sum + l.amount, 0);
    const totalCredits = entry.lines
      .filter((l) => l.direction === 'credit')
      .reduce((sum, l) => sum + l.amount, 0);

    const diff = Math.abs(totalDebits - totalCredits);
    if (diff > 0.001) {
      return {
        success: false,
        error: `Double-entry invariant violated: Debits ($${totalDebits.toFixed(2)}) must equal Credits ($${totalCredits.toFixed(2)}). Variance: $${diff.toFixed(2)}`,
      };
    }

    const newEntry: JournalEntry = {
      id: `je_${Date.now()}`,
      entryNumber: `JE-MAN-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toISOString(),
      description: entry.description,
      referenceType: entry.referenceType,
      referenceId: entry.referenceId || `ref_${Date.now()}`,
      tenantId: selectedTenantId,
      postedBy: 'PLATFORM_COMPLIANCE_OFFICER',
      lines: entry.lines,
    };

    setJournalEntries((prev) => [newEntry, ...prev]);

    // Update account balances
    setLedgerAccounts((prev) =>
      prev.map((acct) => {
        let balanceChange = 0;
        entry.lines.forEach((line) => {
          if (line.accountId === acct.id) {
            if (acct.normalBalance === 'debit') {
              balanceChange += line.direction === 'debit' ? line.amount : -line.amount;
            } else {
              balanceChange += line.direction === 'credit' ? line.amount : -line.amount;
            }
          }
        });
        return balanceChange !== 0 ? { ...acct, balance: acct.balance + balanceChange } : acct;
      })
    );

    return { success: true };
  };

  const updateKybCaseStatus = (
    caseId: string,
    status: KybCase['status'],
    reviewerNote?: string
  ) => {
    setKybCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const updatedNotes = reviewerNote
            ? [...c.reviewerNotes, `[${new Date().toLocaleTimeString()}] ${reviewerNote}`]
            : c.reviewerNotes;
          return { ...c, status, reviewerNotes: updatedNotes };
        }
        return c;
      })
    );

    // If approved, update merchant status
    const targetCase = kybCases.find((c) => c.id === caseId);
    if (targetCase) {
      const merchantStatus =
        status === 'approved'
          ? 'kyb_approved'
          : status === 'action_required'
          ? 'action_required'
          : status === 'rejected'
          ? 'rejected'
          : 'under_review';

      setMerchants((prev) =>
        prev.map((m) =>
          m.id === targetCase.merchantId
            ? {
                ...m,
                onboardingStatus: merchantStatus,
                kybVerificationPassed: status === 'approved',
              }
            : m
        )
      );

      dispatchTestWebhook(`kyb.${status}`, {
        case_id: caseId,
        merchant_id: targetCase.merchantId,
        legal_name: targetCase.legalBusinessName,
        status,
        note: reviewerNote,
      });
    }
  };

  const runAutoReconcile = (batchId: string) => {
    setReconBatches((prev) =>
      prev.map((b) => {
        if (b.id === batchId) {
          return {
            ...b,
            matchedCount: b.internalTransactionsCount,
            exceptionsCount: 0,
            status: 'balanced',
            varianceAmount: 0.0,
            externalTotalAmount: b.internalTotalAmount,
          };
        }
        return b;
      })
    );

    setDiscrepancies((prev) =>
      prev.map((d) => (d.batchId === batchId ? { ...d, status: 'cleared', notes: 'Auto-matched via FedNow/BAI2 ISO 20022 message ID verification.' } : d))
    );

    setPayouts((prev) => prev.map((p) => ({ ...p, reconciled: true })));
  };

  const resolveDiscrepancy = (id: string, notes?: string) => {
    setDiscrepancies((prev) =>
      prev.map((d) =>
        d.id === id
          ? {
              ...d,
              status: 'cleared',
              notes: notes || 'Manually reviewed and cleared by Settlement Operations team.',
            }
          : d
      )
    );
  };

  const executeFxConversion = (
    from: Currency,
    to: Currency,
    fromAmount: number
  ): { toAmount: number; rate: number; fee: number } => {
    // Look up rate
    const directPair = fxRates.find((r) => r.from === from && r.to === to);
    const inversePair = fxRates.find((r) => r.from === to && r.to === from);

    let effectiveRate = 1.0;
    if (directPair) {
      effectiveRate = directPair.rate;
    } else if (inversePair) {
      effectiveRate = 1 / inversePair.rate;
    }

    const fee = fromAmount * 0.0015; // 15 bps spread fee
    const netFrom = fromAmount - fee;
    const toAmount = Number((netFrom * effectiveRate).toFixed(2));

    // Post to ledger
    postJournalEntry({
      description: `Treasury FX Spot Conversion: ${fromAmount} ${from} -> ${toAmount} ${to}`,
      referenceType: 'fx_conversion',
      lines: [
        {
          accountId: 'acct_1010',
          accountCode: '1010',
          accountName: 'FedNow Master Settlement Asset',
          direction: 'debit',
          amount: toAmount,
          currency: to,
        },
        {
          accountId: 'acct_1030',
          accountCode: '1030',
          accountName: 'Multi-Currency Correspondent Asset (EUR/GBP)',
          direction: 'credit',
          amount: toAmount,
          currency: to,
        },
      ],
    });

    return { toAmount, rate: effectiveRate, fee };
  };

  const dispatchTestWebhook = (eventType: string, payload?: Record<string, unknown>) => {
    const newEvent: WebhookEvent = {
      id: `wh_evt_${Date.now()}`,
      event: eventType,
      timestamp: new Date().toISOString(),
      tenantId: selectedTenantId,
      status: 'delivered',
      httpStatus: 200,
      payload: payload || {
        event: eventType,
        tenant_id: selectedTenantId,
        timestamp: new Date().toISOString(),
      },
      signature: `t=${Math.floor(Date.now() / 1000)},v1=${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    };

    setWebhooks((prev) => [newEvent, ...prev]);
  };

  const systemStats = useMemo(() => {
    const totalGtv = tenants.reduce((acc, t) => acc + t.totalGtvUsd, 0);
    const settledPayoutsToday = payouts
      .filter((p) => p.status === 'settled')
      .reduce((acc, p) => acc + p.amount, 0);
    const activeMerchants = merchants.filter((m) => m.onboardingStatus === 'kyb_approved').length;
    const ledgerBalanceUsd = ledgerAccounts
      .filter((a) => a.type === 'asset' && a.currency === 'USD')
      .reduce((acc, a) => acc + a.balance, 0);
    const unreconciledExceptions = discrepancies.filter((d) => d.status !== 'cleared').length;
    const pendingKybReviews = kybCases.filter((c) => c.status === 'pending_review').length;

    return {
      totalGtv,
      settledPayoutsToday,
      activeMerchants,
      ledgerBalanceUsd,
      unreconciledExceptions,
      pendingKybReviews,
    };
  }, [tenants, payouts, merchants, ledgerAccounts, discrepancies, kybCases]);

  return (
    <PaymentsContext.Provider
      value={{
        environment,
        setEnvironment,
        activeTab,
        setActiveTab,
        tenants,
        selectedTenantId,
        setSelectedTenantId,
        activeTenant,
        updateTenant,
        merchants,
        tenantMerchants,
        addMerchant,
        payouts,
        tenantPayouts,
        createPayout,
        ledgerAccounts,
        journalEntries,
        tenantJournalEntries,
        postJournalEntry,
        kybCases,
        tenantKybCases,
        updateKybCaseStatus,
        reconBatches,
        discrepancies,
        runAutoReconcile,
        resolveDiscrepancy,
        fxRates,
        executeFxConversion,
        webhooks,
        dispatchTestWebhook,
        systemStats,
      }}
    >
      {children}
    </PaymentsContext.Provider>
  );
};

export const usePayments = () => {
  const context = useContext(PaymentsContext);
  if (!context) {
    throw new Error('usePayments must be used within a PaymentsProvider');
  }
  return context;
};
